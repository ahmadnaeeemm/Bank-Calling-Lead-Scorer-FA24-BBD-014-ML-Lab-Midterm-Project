"""BACKEND (FastAPI): .

- GET  /                          -> sends the web page (templates/index.html)
- GET  /api/...                   -> sends data to the page (dataset summary, model list ...)
- POST /api/classification/...    -> trains classifiers      (code in src/components/classifiers.py)
- POST /api/regression/...        -> trains regression models (code in src/components/regressors.py)
- POST /api/predict               -> predicts one new customer

Run from the project root:  python app.py   (then open http://127.0.0.1:5000; API docs at /docs)
"""

import json
import os
from pathlib import Path

import uvicorn
from fastapi import FastAPI, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.exceptions import HTTPException as StarletteHTTPException

from src.components.data_ingestion import describe_dataset, preview_rows, subscription_rate_by
from src.components.model_trainer import ExperimentService
from src.exception import DatasetError, ValidationError
from src.logger import get_logger
from src.utils import PROJECT_ROOT, load_config, project_path

log = get_logger("app")
templates = Jinja2Templates(directory=PROJECT_ROOT / "templates")


async def _json_body(request: Request) -> object:
    if "application/json" not in request.headers.get("content-type", ""):
        raise ValidationError("Request body must be valid JSON with Content-Type: application/json")
    try:
        return await request.json()
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise ValidationError("Request body must be valid JSON with Content-Type: application/json") from None


def _int_arg(request: Request, name: str, default: int) -> int:
    value = request.query_params.get(name, default)
    try:
        return int(value)
    except (TypeError, ValueError):
        raise ValidationError(f"Query parameter '{name}' must be a whole number", name) from None


def create_app(service: ExperimentService | None = None, warm_start: bool = True,
               models_dir: Path | None = None) -> FastAPI:
    """Build the app.

    models_dir: register models saved by the train pipeline. warm_start: if no classifier is available,
    train default logistic regression so the Lead Evaluator is usable at once.
    """
    app = FastAPI(title="Lead Scoring Workbench API", version="0.1.0",
                  description="Train, compare and apply classification and regression models on the bank "
                              "marketing dataset. Every POST endpoint takes and returns JSON.")
    app.mount("/static", StaticFiles(directory=PROJECT_ROOT / "static"), name="static")
    service = service or ExperimentService()
    summary = describe_dataset(service.raw)
    if models_dir is not None:
        loaded = service.load_models(models_dir)
        log.info("Loaded %d saved model(s) from %s", len(loaded), models_dir)
    if warm_start and not any(m["task"] == "classification" for m in service.trained_models()):
        service.train_classifier({"model": "logistic_regression"})

    @app.exception_handler(ValidationError)
    @app.exception_handler(DatasetError)
    async def bad_request(request: Request, error: ValueError) -> JSONResponse:
        return JSONResponse({"error": str(error), "field": getattr(error, "field", None)}, status_code=400)

    @app.exception_handler(StarletteHTTPException)
    async def http_error(request: Request, error: StarletteHTTPException) -> JSONResponse:
        return JSONResponse({"error": error.detail}, status_code=error.status_code)

    @app.exception_handler(Exception)
    async def server_error(request: Request, error: Exception) -> JSONResponse:
        log.exception("Unhandled error while serving %s", request.url.path)
        return JSONResponse({"error": f"Internal error: {type(error).__name__}. See the server log for details."},
                            status_code=500)

    # ---------- The web page ----------

    @app.get("/", response_class=HTMLResponse, include_in_schema=False)
    async def index(request: Request):
        return templates.TemplateResponse(request, "index.html")

    # ---------- Data for the page (dataset and model lists) ----------

    @app.get("/api/health", tags=["status"])
    async def health() -> dict:
        return {"status": "ok", "rows": len(service.raw), "trained_models": len(service.trained_models())}

    @app.get("/api/dataset", tags=["dataset"])
    async def dataset() -> dict:
        return summary

    @app.get("/api/dataset/preview", tags=["dataset"])
    async def dataset_preview(request: Request) -> dict:
        return preview_rows(service.raw, _int_arg(request, "offset", 0), _int_arg(request, "limit", 25))

    @app.get("/api/dataset/rates", tags=["dataset"])
    async def dataset_rates(column: str = "job") -> dict:
        return {"column": column, "rates": subscription_rate_by(service.raw, column)}

    @app.get("/api/models", tags=["models"])
    async def models() -> dict:
        return service.catalog()

    @app.get("/api/models/trained", tags=["models"])
    async def trained() -> dict:
        return {"models": service.trained_models()}

    # ---------- CLASSIFICATION: train one classifier, or compare all 3 ----------
    # Training can take a few seconds, so it runs in a separate thread and the server stays responsive.

    @app.post("/api/classification/train", tags=["classification"])
    async def classification_train(request: Request) -> dict:
        return await run_in_threadpool(service.train_classifier, await _json_body(request))

    @app.post("/api/classification/compare", tags=["classification"])
    async def classification_compare(request: Request) -> dict:
        return await run_in_threadpool(service.compare_classifiers, await _json_body(request))

    # ---------- REGRESSION: train one regression model, or compare both ----------

    @app.post("/api/regression/train", tags=["regression"])
    async def regression_train(request: Request) -> dict:
        return await run_in_threadpool(service.train_regressor, await _json_body(request))

    @app.post("/api/regression/compare", tags=["regression"])
    async def regression_compare(request: Request) -> dict:
        return await run_in_threadpool(service.compare_regressors, await _json_body(request))

    # ---------- PREDICTION for one new customer ----------

    @app.post("/api/predict", tags=["prediction"])
    async def predict(request: Request) -> dict:
        return await run_in_threadpool(service.predict, await _json_body(request))

    return app


if __name__ == "__main__":
    config = load_config()
    host = os.environ.get("HOST", config["server"]["host"])
    port = int(os.environ.get("PORT", config["server"]["port"]))
    application = create_app(models_dir=project_path(config["artifacts"]["models_dir"]))
    print("Lead Scoring Workbench running on", "http://" + host + ":" + str(port))
    print("API documentation on", "http://" + host + ":" + str(port) + "/docs")
    uvicorn.run(application, host=host, port=port, log_level="info")

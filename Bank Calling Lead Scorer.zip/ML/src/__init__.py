"""Term deposit lead scoring: data, models and pipelines for the bank marketing dataset."""

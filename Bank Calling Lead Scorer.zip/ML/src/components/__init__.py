"""Pipeline components: ingestion, transformation, models, evaluation and training."""

"""CLASSIFICATION MODELS: predict "yes" or "no" (will the customer open a term deposit?).

This file holds all 3 classifiers. Each one has its own section below, marked with a banner like
    # CLASSIFICATION 1: LOGISTIC REGRESSION
Each section has:
    1. a ModelSpec: the model's name, a one-line description and the settings shown in the web page
    2. a make_...() function that creates the scikit-learn model from those settings

Order of the sections (from simplest to strongest):
    1. Logistic Regression   – the simple baseline: a weighted sum of the inputs
    2. Decision Tree         – one tree of yes/no questions
    3. Random Forest         – many trees that vote (usually the best of the three)
"""

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.tree import DecisionTreeClassifier, export_text

from src.components.data_transform import build_preprocessor
from src.components.model_params import ModelSpec, Param


# =====================================================================================================
# CLASSIFICATION 1: LOGISTIC REGRESSION
# Draws a straight-line boundary and turns the result into a probability between 0 and 1.
# =====================================================================================================

LOGISTIC_REGRESSION = ModelSpec(
    "logistic_regression", "Logistic Regression",
    "Estimates the probability of \"yes\" from a weighted sum of the inputs.",
    (Param("C", "Regularisation (C)", "float", 1.0, 0.001, 1000.0,
           help="Smaller values keep the model simpler."),
     Param("max_iter", "Max iterations", "int", 1000, 50, 10000)))


def make_logistic_regression(params, random_state):
    return LogisticRegression(C=params["C"], max_iter=params["max_iter"])


# =====================================================================================================
# CLASSIFICATION 2: DECISION TREE
# Asks a chain of yes/no questions about the inputs (for example "is age > 60?") to reach an answer.
# =====================================================================================================

DECISION_TREE = ModelSpec(
    "decision_tree", "Decision Tree",
    "Splits customers with a series of simple questions about their inputs.",
    (Param("criterion", "Split criterion", "choice", "gini", options=("gini", "entropy")),
     Param("max_depth", "Max depth", "int", 5, 1, 50, nullable=True,
           help="How many questions deep the tree can go. Leave empty for no limit."),
     Param("min_samples_leaf", "Min customers per leaf", "int", 1, 1, 500)))


def make_decision_tree(params, random_state):
    return DecisionTreeClassifier(criterion=params["criterion"], max_depth=params["max_depth"],
                                  min_samples_leaf=params["min_samples_leaf"], random_state=random_state)


# =====================================================================================================
# CLASSIFICATION 3: RANDOM FOREST
# Trains many decision trees on random parts of the data and lets them vote.
# =====================================================================================================

RANDOM_FOREST = ModelSpec(
    "random_forest", "Random Forest",
    "Many decision trees, each trained on a random sample, vote on the answer.",
    (Param("n_estimators", "Number of trees", "int", 100, 10, 1000),
     Param("max_depth", "Max depth", "int", None, 1, 50, nullable=True,
           help="How deep each tree can go. Leave empty for no limit."),
     Param("min_samples_leaf", "Min customers per leaf", "int", 1, 1, 500)))


def make_random_forest(params, random_state):
    # random_state comes from configs/config.yaml (42 by default), so results are repeatable.
    # n_jobs=-1 trains the trees on all CPU cores at once.
    return RandomForestClassifier(n_estimators=params["n_estimators"], max_depth=params["max_depth"],
                                  min_samples_leaf=params["min_samples_leaf"], random_state=random_state,
                                  n_jobs=-1)


# =====================================================================================================
# LOOK-UP TABLES used by the rest of the app
# =====================================================================================================

# Every classifier's spec, by key (this order is the order shown in the web page).
SPECS = {spec.key: spec for spec in [LOGISTIC_REGRESSION, DECISION_TREE, RANDOM_FOREST]}

# The function that builds each model.
MAKERS = {
    "logistic_regression": make_logistic_regression,
    "decision_tree": make_decision_tree,
    "random_forest": make_random_forest,
}

# How each model wants its numeric inputs scaled before training:
#   "standard" = mean 0 and spread 1 (logistic regression compares weights, so inputs need a similar scale)
#   None       = leave the numbers as they are (trees do not care about scale)
SCALING = {
    "logistic_regression": "standard",
    "decision_tree": None,
    "random_forest": None,
}


# =====================================================================================================
# BUILDING AND USING A CLASSIFIER
# =====================================================================================================

def build_estimator(key, params, random_state):
    """Create the bare scikit-learn model for one classifier."""
    if key not in MAKERS:
        raise KeyError(f"Unknown classifier '{key}'")
    return MAKERS[key](params, random_state)


def build_pipeline(key, params, features, random_state):
    """Chain the data preparation and the model, so both always run together.

    Step 1 "preprocess": scale the numbers and turn categories into 0/1 columns.
    Step 2 "model":      the classifier itself.
    """
    return Pipeline([
        ("preprocess", build_preprocessor(features, SCALING[key])),
        ("model", build_estimator(key, params, random_state)),
    ])


def probability_of_yes(pipeline, X):
    """The chance (0 to 1) that each customer says "yes". Column 1 of predict_proba is the "yes" class."""
    return pipeline.predict_proba(X)[:, 1]


def clean_name(name):
    """Turn scikit-learn column names like "cat__job_retired" into "job_retired"."""
    return str(name).split("__", 1)[-1]


def top_items(names, values, limit=10):
    """The `limit` biggest values (ignoring the sign), with their cleaned-up names."""
    order = np.argsort(-np.abs(values))[:limit]
    return [(clean_name(names[i]), float(values[i])) for i in order]


def describe_model(key, pipeline, X_train, y_train, X_test, features, params, random_state):
    """Extra, easy-to-read information about a trained model, shown under "Model details"."""
    names = pipeline.named_steps["preprocess"].get_feature_names_out()
    model = pipeline.named_steps["model"]
    details = {}

    # Logistic regression: which inputs push the answer most towards "yes" or "no".
    if key == "logistic_regression":
        details["weights"] = [{"term": n, "weight": w} for n, w in top_items(names, model.coef_.ravel())]

    # Decision tree and random forest: the inputs the trees rely on most.
    if key in ("decision_tree", "random_forest"):
        details["importances"] = [{"term": n, "importance": v}
                                  for n, v in top_items(names, model.feature_importances_) if v > 0]

    # Decision tree: its size and the first few questions it asks.
    if key == "decision_tree":
        details["depth"] = int(model.get_depth())
        details["leaves"] = int(model.get_n_leaves())
        details["rules"] = export_text(model, feature_names=[clean_name(n) for n in names], max_depth=3,
                                       class_names=["no", "yes"], decimals=2)

    # Random forest: how many trees it used.
    if key == "random_forest":
        details["trees"] = len(model.estimators_)

    return details

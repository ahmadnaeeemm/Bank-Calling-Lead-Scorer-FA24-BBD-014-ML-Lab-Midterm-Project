"""DATA LOADING (data ingestion): read bank.csv, check it, and describe it.

What happens here:
    - read_raw_dataset():       load the CSV and check that every column is there and has the right type
    - split_features_target():  separate the inputs (X) from the answer we want to predict (y = deposit)
    - describe_dataset():       summary numbers for the Dataset tab
    - subscription_rate_by():   share of "yes" per group, for the Dataset tab chart
"""

from pathlib import Path

import numpy as np
import pandas as pd

from src.exception import DatasetError
from src.utils import load_config, project_path

DATA_PATH = project_path(load_config()["data"]["raw_path"])
TARGET = "deposit"
CLASS_LABELS = ("no", "yes")  # encoded as 0 and 1; "yes" is the positive class
# Call duration is only known after the call ends, so it would leak the outcome.
LEAKY_COLUMNS = ["duration"]

NUMERIC_FEATURES = ["age", "balance", "day", "campaign", "pdays", "previous"]
CATEGORICAL_FEATURES = [
    "job", "marital", "education", "default", "housing", "loan", "contact", "month", "poutcome",
]
# Model inputs in the dataset's own column order.
FEATURES = [
    "age", "job", "marital", "education", "default", "balance", "housing", "loan",
    "contact", "day", "month", "campaign", "pdays", "previous", "poutcome",
]
EXPECTED_COLUMNS = [*FEATURES[:11], "duration", *FEATURES[11:], TARGET]
# Order of inputs on prediction forms; the first eight pair up as in the reference screenshot.
DISPLAY_ORDER = [
    "age", "job", "marital", "education", "balance", "poutcome", "housing", "loan",
    "default", "previous", "pdays", "contact", "month", "day", "campaign",
]

FEATURE_GROUPS = [
    ("demographics", "Customer demographics"),
    ("financial", "Financial standing & history"),
    ("campaign", "Campaign contact plan"),
]

YES_NO = {"no": "No", "yes": "Yes"}
FEATURE_INFO: dict[str, dict] = {
    "age": {"label": "Age", "group": "demographics", "unit": "years",
            "description": "Customer age in years."},
    "job": {"label": "Occupation", "group": "demographics",
            "description": "Type of occupation.",
            "options": {"admin.": "Admin", "blue-collar": "Blue-collar", "entrepreneur": "Entrepreneur",
                        "housemaid": "Housemaid", "management": "Management", "retired": "Retired",
                        "self-employed": "Self-employed", "services": "Services", "student": "Student",
                        "technician": "Technician", "unemployed": "Unemployed", "unknown": "Unknown"}},
    "marital": {"label": "Marital Status", "group": "demographics",
                "description": "Marital status.",
                "options": {"divorced": "Divorced", "married": "Married", "single": "Single"}},
    "education": {"label": "Education", "group": "demographics",
                  "description": "Highest education level attained.",
                  "options": {"primary": "Primary", "secondary": "Secondary",
                              "tertiary": "University / Tertiary", "unknown": "Unknown"}},
    "default": {"label": "Credit in Default?", "group": "financial",
                "description": "Whether the customer has credit in default.", "options": YES_NO},
    "balance": {"label": "Average Yearly Balance", "group": "financial", "unit": "currency units",
                "description": "Average yearly account balance (currency not stated in the source)."},
    "housing": {"label": "Active Housing Loan?", "group": "financial",
                "description": "Whether the customer has a housing loan.", "options": YES_NO},
    "loan": {"label": "Active Personal Loan?", "group": "financial",
             "description": "Whether the customer has a personal loan.", "options": YES_NO},
    "poutcome": {"label": "Prior Campaign Outcome", "group": "financial",
                 "description": "Outcome of the previous marketing campaign.",
                 "options": {"unknown": "First time (no prior outreach)", "failure": "Did not subscribe",
                             "success": "Subscribed", "other": "Other outcome"}},
    "pdays": {"label": "Days Since Last Campaign Contact", "group": "financial", "unit": "days",
              "description": "Days since the customer was last contacted in a previous campaign; -1 means never."},
    "previous": {"label": "Contacts Before This Campaign", "group": "financial", "unit": "contacts",
                 "description": "Number of contacts performed before this campaign."},
    "contact": {"label": "Contact Channel", "group": "campaign",
                "description": "Communication channel used.",
                "options": {"cellular": "Cellular", "telephone": "Telephone", "unknown": "Unknown"}},
    "day": {"label": "Contact Day of Month", "group": "campaign", "unit": "day",
            "description": "Day of the month of the (planned) contact."},
    "month": {"label": "Contact Month", "group": "campaign",
              "description": "Month of the (planned) contact.",
              "options": {m: m.capitalize() for m in
                          ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]}},
    "campaign": {"label": "Contacts in This Campaign", "group": "campaign", "unit": "contacts",
                 "description": "Number of contacts performed during this campaign, including this one."},
}


def read_raw_dataset(path: Path = DATA_PATH) -> pd.DataFrame:
    """Read and validate the CSV exactly as supplied, including leaky columns."""
    if not path.is_file():
        raise FileNotFoundError(f"Dataset not found: {path}")
    try:
        df = pd.read_csv(path)
    except pd.errors.EmptyDataError as exc:
        raise DatasetError(f"Dataset file is empty: {path.name}") from exc
    return validate_dataset(df)


def validate_dataset(df: pd.DataFrame) -> pd.DataFrame:
    """Check columns, types, nulls and target values; return a typed copy."""
    if df.empty:
        raise DatasetError("Dataset has no rows")
    missing = [c for c in EXPECTED_COLUMNS if c not in df.columns]
    if missing:
        raise DatasetError(f"Dataset is missing expected columns: {missing}")
    df = df[EXPECTED_COLUMNS].copy()
    nulls = {c: int(n) for c, n in df.isna().sum().items() if n}
    if nulls:
        raise DatasetError(f"Dataset has empty cells: {nulls}")
    for column in [*NUMERIC_FEATURES, *LEAKY_COLUMNS]:
        converted = pd.to_numeric(df[column], errors="coerce")
        if converted.isna().any():
            bad = df.loc[converted.isna(), column].astype(str).unique()[:5].tolist()
            raise DatasetError(f"Column '{column}' must be numeric; found {bad}")
        df[column] = converted
    for column in [*CATEGORICAL_FEATURES, TARGET]:
        df[column] = df[column].astype(str).str.strip()
    bad_target = sorted(set(df[TARGET]) - set(CLASS_LABELS))
    if bad_target:
        raise DatasetError(f"Unexpected target values: {bad_target}")
    return df


def load_dataset(path: Path = DATA_PATH) -> pd.DataFrame:
    """Read the CSV and drop columns that are not available before the call."""
    return read_raw_dataset(path).drop(columns=LEAKY_COLUMNS)


def split_features_target(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Split into inputs X and a 0/1 target y (1 = subscribed)."""
    if TARGET not in df.columns:
        raise ValueError(f"Target column '{TARGET}' not found")
    y = df[TARGET].map({label: code for code, label in enumerate(CLASS_LABELS)})
    if y.isna().any():
        bad = sorted(df.loc[y.isna(), TARGET].astype(str).unique())
        raise ValueError(f"Unexpected target values: {bad}")
    return df.drop(columns=[TARGET]), y.astype(int)


def describe_dataset(raw: pd.DataFrame) -> dict:
    """Summarise the raw dataset for the dataset view (computed, never hard-coded)."""
    target_counts = raw[TARGET].value_counts()
    numeric = []
    for column in NUMERIC_FEATURES + LEAKY_COLUMNS:
        values = raw[column]
        q1, q3 = values.quantile([0.25, 0.75])
        iqr = q3 - q1
        outliers = int(((values < q1 - 1.5 * iqr) | (values > q3 + 1.5 * iqr)).sum())
        numeric.append({
            "name": column, "min": float(values.min()), "max": float(values.max()),
            "mean": float(values.mean()), "median": float(values.median()),
            "std": float(values.std()), "iqr_outliers": outliers,
        })
    categorical = []
    for column in CATEGORICAL_FEATURES:
        counts = raw[column].value_counts()
        categorical.append({
            "name": column, "levels": int(counts.size),
            "unknown": int(counts.get("unknown", 0)),
            "counts": {str(k): int(v) for k, v in counts.items()},
        })
    columns = []
    for column in EXPECTED_COLUMNS:
        if column == TARGET:
            role = "target"
        elif column in LEAKY_COLUMNS:
            role = "dropped"
        else:
            role = "feature"
        kind = "numeric" if column in NUMERIC_FEATURES + LEAKY_COLUMNS else "categorical"
        info = FEATURE_INFO.get(column, {})
        description = info.get("description", "")
        if column == TARGET:
            description = "Whether the customer subscribed to a term deposit."
        elif column in LEAKY_COLUMNS:
            description = "Last call duration in seconds. Only known after the call, so it leaks the outcome."
        columns.append({
            "name": column, "label": info.get("label", column), "kind": kind, "role": role,
            "unique": int(raw[column].nunique()), "description": description,
        })
    return {
        "file": DATA_PATH.name,
        "rows": int(len(raw)),
        "columns": int(raw.shape[1]),
        "features_used": len(FEATURES),
        "dropped": LEAKY_COLUMNS,
        "missing_cells": int(raw.isna().sum().sum()),
        "duplicate_rows": int(raw.duplicated().sum()),
        "target": TARGET,
        "target_counts": {label: int(target_counts.get(label, 0)) for label in CLASS_LABELS},
        "pdays_never_contacted": int((raw["pdays"] == -1).sum()),
        "columns_info": columns,
        "numeric_summary": numeric,
        "categorical_summary": categorical,
    }


def subscription_rate_by(raw: pd.DataFrame, column: str) -> list[dict]:
    """Share of 'yes' per category (or per quantile bin for numeric columns)."""
    if column not in FEATURES:
        raise DatasetError(f"Unknown feature '{column}'")
    is_yes = (raw[TARGET] == CLASS_LABELS[1]).astype(float)
    if column in NUMERIC_FEATURES:
        # Quantile bins stay in numeric order; labels show the actual value range of each bin.
        bins = pd.qcut(raw[column], q=5, duplicates="drop")
        table = is_yes.groupby(bins, observed=True).agg(["mean", "size"])
        ranges = raw[column].groupby(bins, observed=True).agg(["min", "max"])
        labels = [f"{lo:,.0f} to {hi:,.0f}" for lo, hi in zip(ranges["min"], ranges["max"])]
    else:
        table = is_yes.groupby(raw[column]).agg(["mean", "size"]).sort_values("mean", ascending=False)
        options = FEATURE_INFO[column].get("options", {})
        labels = [options.get(str(k), str(k)) for k in table.index]
    return [{"group": label, "rate": float(r["mean"]), "count": int(r["size"])}
            for label, (_, r) in zip(labels, table.iterrows())]


def preview_rows(raw: pd.DataFrame, offset: int, limit: int) -> dict:
    """Return a slice of the raw dataset for display."""
    if offset < 0 or not 1 <= limit <= 200:
        raise DatasetError("offset must be >= 0 and limit between 1 and 200")
    page = raw.iloc[offset:offset + limit]
    rows = [[None if isinstance(v, float) and np.isnan(v) else (v.item() if hasattr(v, "item") else v)
             for v in row] for row in page.itertuples(index=False)]
    return {"columns": list(raw.columns), "rows": rows, "offset": offset, "total": int(len(raw))}

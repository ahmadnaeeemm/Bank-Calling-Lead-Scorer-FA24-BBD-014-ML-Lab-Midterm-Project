"""DATA PREPARATION (preprocessing): get the data ready for the models.

What happens here:
    - make_split():          split the rows into a training part and a test part
    - build_preprocessor():  scale the numeric inputs and turn category inputs into 0/1 columns
    - input_schema():        describe the inputs a new customer needs (used to build the web forms)
    - validate_sample():     check the values typed into a form before predicting
"""

import math
from dataclasses import dataclass

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from src.components.data_ingestion import (CATEGORICAL_FEATURES, DISPLAY_ORDER, FEATURE_GROUPS, FEATURE_INFO,
                                           FEATURES, NUMERIC_FEATURES)
from src.exception import ValidationError

SCALERS = {"standard": StandardScaler}
TEST_SIZE_RANGE = (0.1, 0.5)


@dataclass(frozen=True)
class Split:
    X_train: pd.DataFrame
    X_test: pd.DataFrame
    y_train: pd.Series
    y_test: pd.Series


def validate_split_settings(test_size: object, random_state: object) -> tuple[float, int]:
    """Coerce and range-check the evaluation split settings."""
    try:
        test_size = float(test_size)
    except (TypeError, ValueError):
        raise ValidationError("Test size must be a number", "test_size") from None
    low, high = TEST_SIZE_RANGE
    if not low <= test_size <= high:
        raise ValidationError(f"Test size must be between {low:.0%} and {high:.0%}", "test_size")
    if isinstance(random_state, bool) or not isinstance(random_state, (int, float, str)):
        raise ValidationError("Random seed must be a whole number", "random_state")
    try:
        seed = int(random_state)
    except ValueError:
        raise ValidationError("Random seed must be a whole number", "random_state") from None
    if seed != float(random_state) or not 0 <= seed <= 2**31 - 1:
        raise ValidationError("Random seed must be a whole number between 0 and 2147483647", "random_state")
    return test_size, seed


def validate_features(features: object, allowed: list[str], minimum: int = 1) -> list[str]:
    """Check the requested feature list and return it in the dataset's column order."""
    if not isinstance(features, list) or not all(isinstance(f, str) for f in features):
        raise ValidationError("Features must be a list of column names", "features")
    unknown = sorted(set(features) - set(allowed))
    if unknown:
        raise ValidationError(f"Features not allowed here: {unknown}", "features")
    if len(set(features)) < minimum:
        raise ValidationError(f"Select at least {minimum} feature(s)", "features")
    return [f for f in FEATURES if f in features]


def make_split(X: pd.DataFrame, y: pd.Series, test_size: float, random_state: int,
               stratify: bool) -> Split:
    """Split the rows into a training part (to learn from) and a test part (to check the model on).

    The test part is never used for training, so the test scores show how the model does on new customers.
    """
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y if stratify else None)
    return Split(X_train, X_test, y_train, y_test)


def split_columns(features: list[str]) -> tuple[list[str], list[str]]:
    return ([f for f in features if f in NUMERIC_FEATURES],
            [f for f in features if f in CATEGORICAL_FEATURES])


def build_preprocessor(features: list[str], scaling: str | None = "standard",
                       drop_first: bool = False) -> ColumnTransformer:
    """Prepare the inputs for a model.

    - Numeric columns (age, balance ...) are scaled: "standard", or None to leave them as they are.
    - Category columns (job, marital ...) are one-hot encoded: "job" becomes job_admin, job_retired ... with 0 or 1.
    """
    numeric, categorical = split_columns(features)
    transformers = []

    # Numeric inputs
    if numeric:
        scaler = SCALERS[scaling]() if scaling else "passthrough"
        transformers.append(("num", scaler, numeric))

    # Category inputs
    if categorical:
        encoder = OneHotEncoder(handle_unknown="ignore", drop="first" if drop_first else None,
                                sparse_output=False)
        transformers.append(("cat", encoder, categorical))
    return ColumnTransformer(transformers, verbose_feature_names_out=True)


def input_schema(features: list[str], X_train: pd.DataFrame) -> list[dict]:
    """Describe each input a new sample must provide, derived from the training data only."""
    group_order = {key: i for i, (key, _) in enumerate(FEATURE_GROUPS)}
    schema = []
    for name in features:
        info = FEATURE_INFO[name]
        column = X_train[name]
        field = {"name": name, "label": info["label"], "group": info["group"],
                 "description": info["description"], "unit": info.get("unit")}
        if name in NUMERIC_FEATURES:
            field.update(kind="number", min=float(column.min()), max=float(column.max()),
                         default=float(column.median()), integer=True)
        else:
            labels = info.get("options", {})
            levels = sorted(column.unique().tolist())
            field.update(kind="category", default=str(column.mode().iloc[0]),
                         options=[{"value": v, "label": labels.get(v, v)} for v in levels])
        schema.append(field)
    return sorted(schema, key=lambda f: (group_order[f["group"]], DISPLAY_ORDER.index(f["name"])))


def validate_sample(values: object, schema: list[dict]) -> tuple[pd.DataFrame, list[str]]:
    """Check a new sample against the schema; return a one-row frame and range warnings."""
    if not isinstance(values, dict):
        raise ValidationError("Sample values must be an object of feature: value pairs", "values")
    expected = {f["name"] for f in schema}
    missing = sorted(expected - set(values))
    if missing:
        raise ValidationError(f"Missing values for: {missing}", missing[0])
    extra = sorted(set(values) - expected)
    if extra:
        raise ValidationError(f"This model does not use: {extra}", extra[0])
    row, warnings = {}, []
    for field in schema:
        name, value = field["name"], values[field["name"]]
        if field["kind"] == "number":
            if isinstance(value, bool):
                raise ValidationError(f"{field['label']} must be a number", name)
            try:
                number = float(value)
            except (TypeError, ValueError):
                raise ValidationError(f"{field['label']} must be a number", name) from None
            if not math.isfinite(number):
                raise ValidationError(f"{field['label']} must be a finite number", name)
            if field.get("integer") and number != int(number):
                raise ValidationError(f"{field['label']} must be a whole number", name)
            if not field["min"] <= number <= field["max"]:
                warnings.append(f"{field['label']} = {number:g} is outside the training range "
                                f"{field['min']:g} to {field['max']:g}; the prediction is an extrapolation.")
            row[name] = int(number) if field.get("integer") else number
        else:
            allowed = [o["value"] for o in field["options"]]
            if value not in allowed:
                raise ValidationError(f"{field['label']} must be one of {allowed}", name)
            row[name] = value
    return pd.DataFrame([row], columns=[f["name"] for f in schema]), warnings

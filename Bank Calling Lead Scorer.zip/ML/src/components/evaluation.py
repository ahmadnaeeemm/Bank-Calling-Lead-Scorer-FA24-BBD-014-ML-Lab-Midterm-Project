"""Evaluation: measure how good a model is.

All scores come straight from scikit-learn's ready-made metric functions, so there is no maths to write by hand.
"""

import numpy as np
from sklearn import metrics


# =====================================================================================================
# REGRESSION SCORES (used by the 2 regression models)
# =====================================================================================================

def regression_metrics(y_true, y_pred) -> dict:
    """Return the usual regression scores for one set of predictions.

    - MAE  (mean absolute error): the average size of a mistake. Lower is better.
    - MSE  (mean squared error):  like MAE, but big mistakes count much more. Lower is better.
    - RMSE (root of MSE):         back in the same units as the target. Lower is better.
    - R²   (R squared):           how much of the variation the model explains. 1.0 is perfect.
    """
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    if len(y_true) == 0 or len(y_true) != len(y_pred):
        raise ValueError("y_true and y_pred must be non-empty and the same length")

    mse = metrics.mean_squared_error(y_true, y_pred)

    # R² cannot be calculated when every true value is the same, so report "None" (no value) then.
    r2 = float(metrics.r2_score(y_true, y_pred)) if np.ptp(y_true) > 0 else None

    return {
        "mae": float(metrics.mean_absolute_error(y_true, y_pred)),
        "mse": float(mse),
        "rmse": float(np.sqrt(mse)),
        "r2": r2,
    }


# =====================================================================================================
# CLASSIFICATION SCORES (used by the 3 classifiers)
# =====================================================================================================

def confusion_matrix(y_true, y_pred, labels) -> np.ndarray:
    """Count right and wrong answers. Rows are the real class, columns are the predicted class."""
    return metrics.confusion_matrix(y_true, y_pred, labels=labels)


def classification_report(y_true, y_pred, labels, names) -> dict:
    """Accuracy, plus precision, recall and F1 for each class ("no" and "yes").

    - Accuracy:  share of all customers the model got right.
    - Precision: when the model says "yes", how often is it right?
    - Recall:    of all the real "yes" customers, how many did the model find?
    - F1:        one number that balances precision and recall.
    """
    if len(y_true) == 0:
        raise ValueError("Cannot evaluate an empty set of predictions")

    # zero_division=0 means "report 0 instead of an error" if a class is never predicted.
    precision, recall, f1, support = metrics.precision_recall_fscore_support(
        y_true, y_pred, labels=labels, zero_division=0)

    per_class = []
    for i, name in enumerate(names):
        per_class.append({"label": name, "precision": float(precision[i]), "recall": float(recall[i]),
                          "f1": float(f1[i]), "support": int(support[i])})

    return {
        "accuracy": float(metrics.accuracy_score(y_true, y_pred)),
        "per_class": per_class,
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels).tolist(),
        "labels": list(names),
        "support": int(len(y_true)),
    }


def roc_curve(y_true, scores) -> dict:
    """Points for the ROC curve and the area under it (ROC-AUC).

    ROC-AUC tells you how well the model ranks customers: 1.0 is perfect, 0.5 is no better than guessing.
    """
    y_true = np.asarray(y_true)
    # The curve needs at least one "yes" and one "no" customer.
    if len(np.unique(y_true)) < 2:
        return {"fpr": [], "tpr": [], "auc": None, "reason": "ROC needs both classes in the test set"}

    fpr, tpr, _ = metrics.roc_curve(y_true, scores)
    auc = metrics.roc_auc_score(y_true, scores)
    return {"fpr": fpr.tolist(), "tpr": tpr.tolist(), "auc": float(auc)}


def downsample_curve(xs: list[float], ys: list[float], max_points: int = 200) -> tuple[list, list]:
    """Keep at most max_points points of a curve so the chart in the browser stays fast."""
    if len(xs) <= max_points:
        return xs, ys
    keep = np.unique(np.linspace(0, len(xs) - 1, max_points).round().astype(int))
    return [xs[i] for i in keep], [ys[i] for i in keep]

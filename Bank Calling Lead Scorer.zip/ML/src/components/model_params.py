"""MODEL SETTINGS: describe each model's settings once, then reuse that description everywhere.

- Param:     one setting (for example "Number of trees", a whole number from 10 to 1000, default 100).
- ModelSpec: a model's key, display name, one-line summary and list of settings.
- validate_params(): check the values typed in the web page and fill in defaults for anything left out.

The web page builds its setting boxes from these descriptions, so nothing is written twice.
"""

from dataclasses import asdict, dataclass, field

from src.exception import ValidationError


@dataclass(frozen=True)
class Param:
    name: str
    label: str
    kind: str  # "int", "float" or "choice"
    default: object
    minimum: float | None = None
    maximum: float | None = None
    options: tuple = ()
    nullable: bool = False  # an empty value means "no limit" (e.g. max_depth=None)
    help: str = ""

    def to_json(self) -> dict:
        data = asdict(self)
        data["options"] = list(self.options)
        return data


@dataclass(frozen=True)
class ModelSpec:
    key: str
    label: str
    summary: str
    params: tuple[Param, ...] = field(default_factory=tuple)

    def to_json(self) -> dict:
        return {"key": self.key, "label": self.label, "summary": self.summary,
                "params": [p.to_json() for p in self.params]}


def _coerce_number(param: Param, value: object) -> int | float:
    if isinstance(value, bool):
        raise ValidationError(f"{param.label} must be a number", param.name)
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{param.label} must be a number", param.name) from None
    if param.kind == "int":
        if number != int(number):
            raise ValidationError(f"{param.label} must be a whole number", param.name)
        number = int(number)
    if param.minimum is not None and number < param.minimum:
        raise ValidationError(f"{param.label} must be at least {param.minimum:g}", param.name)
    if param.maximum is not None and number > param.maximum:
        raise ValidationError(f"{param.label} must be at most {param.maximum:g}", param.name)
    return number


def validate_params(spec: ModelSpec, raw: object) -> dict:
    """Return a complete, type-checked parameter dict, filling defaults for omitted values."""
    raw = {} if raw is None else raw
    if not isinstance(raw, dict):
        raise ValidationError("Parameters must be an object", "params")
    known = {p.name: p for p in spec.params}
    unknown = sorted(set(raw) - set(known))
    if unknown:
        raise ValidationError(f"{spec.label} has no parameter(s) {unknown}", unknown[0])
    params = {}
    for name, param in known.items():
        value = raw.get(name, param.default)
        if value is None or value == "":
            if not param.nullable:
                raise ValidationError(f"{param.label} is required", name)
            params[name] = None
        elif param.kind == "choice":
            if str(value) not in [str(o) for o in param.options]:
                raise ValidationError(f"{param.label} must be one of {list(param.options)}", name)
            params[name] = str(value)
        else:
            params[name] = _coerce_number(param, value)
    return params

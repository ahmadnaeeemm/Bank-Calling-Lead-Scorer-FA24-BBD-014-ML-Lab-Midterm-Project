"""MODEL TRAINER: trains, tests and compares the models, and keeps them ready for new predictions.

The main recipe is the same for every model:
    Step 1. Split the data into a training part and a test part.
    Step 2. Build the model pipeline (data preparation + model).
    Step 3. Train it on the training part (pipeline.fit).
    Step 4. Predict the test part and measure how good the predictions are.
    Step 5. Store the trained model so the web page can use it for new customers.

Classification (yes/no) is in train_classifier() and _fit_classifier().
Regression (a number) is in train_regressor() and _fit_regressor().
"""

import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock

import numpy as np
import pandas as pd

from src.components import classifiers as clf
from src.components import regressors as reg
from src.components.data_ingestion import (CLASS_LABELS, DATA_PATH, FEATURE_INFO, FEATURES, LEAKY_COLUMNS,
                                           NUMERIC_FEATURES, TARGET, read_raw_dataset, split_features_target)
from src.components.data_transform import (Split, input_schema, make_split, validate_features, validate_sample,
                                           validate_split_settings)
from src.components.evaluation import classification_report, downsample_curve, regression_metrics, roc_curve
from src.components.model_params import validate_params
from src.exception import ModelNotFoundError, ValidationError
from src.logger import get_logger
from src.utils import load_config, load_object, save_object

CONFIG = load_config()
DEFAULT_TEST_SIZE = CONFIG["split"]["test_size"]   # 20% of the rows are kept back for testing
DEFAULT_SEED = CONFIG["split"]["random_state"]     # fixed seed, so every run gives the same split
MODEL_SUFFIX = ".pkl"
PREDICTION_ROWS = 25    # how many test predictions to show in the web page
MAX_PLOT_POINTS = 500   # how many points to draw in a scatter chart
log = get_logger(__name__)


def now():
    """Current time as text, used to show when a model was trained."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# =====================================================================================================
# A TRAINED MODEL, ready to score new customers
# =====================================================================================================

@dataclass
class TrainedModel:
    task: str               # "classification" or "regression"
    key: str                # e.g. "logistic_regression"
    label: str              # e.g. "Logistic Regression"
    pipeline: object        # the fitted scikit-learn pipeline
    features: list[str]     # the input columns it was trained on
    schema: list[dict]      # what a new customer must provide (used to build the form)
    target: str             # what it predicts
    headline: dict          # the main test scores
    trained_at: str

    def summary(self) -> dict:
        return {"task": self.task, "model": self.key, "label": self.label, "target": self.target,
                "features": self.features, "schema": self.schema,
                "headline": self.headline, "trained_at": self.trained_at}

    @property
    def filename(self) -> str:
        return f"{self.task}__{self.key}{MODEL_SUFFIX}"

    def predict(self, values) -> dict:
        """Check one new customer's values, then predict with this model."""
        sample, warnings = validate_sample(values, self.schema)
        result = {"task": self.task, "model": self.key, "label": self.label, "trained_at": self.trained_at,
                  "warnings": warnings, "headline": self.headline}

        if self.task == "classification":
            predicted = int(self.pipeline.predict(sample)[0])          # 0 = no, 1 = yes
            chance = float(clf.probability_of_yes(self.pipeline, sample)[0])
            # "score" is the chance of "yes"; the model says "yes" when it is 50% or more.
            result.update(predicted=CLASS_LABELS[predicted], score=chance, threshold=0.5)
        else:
            result.update(predicted=float(self.pipeline.predict(sample)[0]), target=self.target,
                          target_label=FEATURE_INFO[self.target]["label"],
                          unit=FEATURE_INFO[self.target].get("unit"))
        return result


def save_model(model: TrainedModel, models_dir: Path) -> Path:
    return save_object(model, models_dir / model.filename)


def load_model(path: Path) -> TrainedModel:
    """Load one model file written by save_model."""
    if not path.is_file():
        raise ModelNotFoundError(f"No saved model at {path}. Run: python -m src.pipelines.train_pipeline")
    model = load_object(path)
    if not isinstance(model, TrainedModel):
        raise TypeError(f"{path.name} does not contain a TrainedModel")
    return model


def _require_choice(value, allowed, field, noun) -> str:
    """Make sure a value from the web page is one of the allowed options."""
    if not isinstance(value, str) or value not in allowed:
        raise ValidationError(f"Unknown {noun} '{value}'. Choose one of {list(allowed)}", field)
    return value


def _pick_rows_for_chart(n, limit, seed) -> np.ndarray:
    """Choose at most `limit` row positions at random, so charts do not get too crowded."""
    if n <= limit:
        return np.arange(n)
    return np.sort(np.random.default_rng(seed).choice(n, size=limit, replace=False))


def _split_info(split: Split, total_rows: int, seed: int, stratified: bool) -> dict:
    return {"train": int(len(split.y_train)), "test": int(len(split.y_test)),
            "test_size": float(len(split.y_test) / total_rows), "random_state": seed, "stratified": stratified}


# =====================================================================================================
# THE SERVICE: holds the dataset and every trained model while the app is running
# =====================================================================================================

class ExperimentService:

    def __init__(self, data_path: Path = DATA_PATH):
        # Load the CSV, drop "duration" (it gives the answer away), then split into inputs X and target y.
        self.raw = read_raw_dataset(data_path)
        self.X, self.y = split_features_target(self.raw.drop(columns=LEAKY_COLUMNS))
        self._models: dict[tuple[str, str], TrainedModel] = {}
        self._lock = Lock()  # stops two requests from changing the model list at the same time

    # ---------- What the web page needs to build its menus ----------

    def catalog(self) -> dict:
        return {
            "classification": {
                "target": TARGET, "classes": list(CLASS_LABELS), "positive_class": CLASS_LABELS[1],
                "features": FEATURES,
                "models": [spec.to_json() for spec in clf.SPECS.values()],
            },
            "regression": {
                "targets": [{"name": t, "label": FEATURE_INFO[t]["label"], "unit": FEATURE_INFO[t].get("unit")}
                            for t in NUMERIC_FEATURES],
                "default_target": CONFIG["regression"]["default_target"],
                "default_features": CONFIG["regression"]["default_features"],
                "features": FEATURES, "models": [spec.to_json() for spec in reg.SPECS.values()],
            },
            "feature_info": {name: {"label": FEATURE_INFO[name]["label"],
                                    "kind": "number" if name in NUMERIC_FEATURES else "category",
                                    "group": FEATURE_INFO[name]["group"]} for name in FEATURES},
            "defaults": {"test_size": DEFAULT_TEST_SIZE, "random_state": DEFAULT_SEED},
            "dropped": LEAKY_COLUMNS,
        }

    # ---------- Keeping track of trained models ----------

    def trained_models(self) -> list[dict]:
        with self._lock:
            return [m.summary() for m in self._models.values()]

    def _store(self, model: TrainedModel) -> None:
        with self._lock:
            self._models[(model.task, model.key)] = model

    def get_model(self, task, key) -> TrainedModel | None:
        with self._lock:
            return self._models.get((task, key))

    def save_models(self, models_dir: Path) -> list[Path]:
        with self._lock:
            models = list(self._models.values())
        return [save_model(m, models_dir) for m in models]

    def load_models(self, models_dir: Path) -> list[str]:
        """Load every saved model file. A broken file is logged and skipped."""
        loaded = []
        for path in sorted(models_dir.glob(f"*{MODEL_SUFFIX}")):
            try:
                model = load_model(path)
            except Exception:
                log.exception("Could not load %s; rerun the train pipeline to replace it", path.name)
                continue
            self._store(model)
            loaded.append(path.name)
        return loaded

    def _read_common_settings(self, request, allowed_features):
        """Read the inputs, test size and seed chosen in the web page (or use the defaults)."""
        if not isinstance(request, dict):
            raise ValidationError("Request body must be a JSON object")
        features = validate_features(request.get("features", allowed_features), allowed_features)
        test_size, seed = validate_split_settings(request.get("test_size", DEFAULT_TEST_SIZE),
                                                  request.get("random_state", DEFAULT_SEED))
        return features, test_size, seed

    # =================================================================================================
    # CLASSIFICATION: train one classifier, or compare all 3
    # =================================================================================================

    def train_classifier(self, request) -> dict:
        features, test_size, seed = self._read_common_settings(request, FEATURES)
        key = _require_choice(request.get("model"), clf.SPECS, "model", "classifier")
        params = validate_params(clf.SPECS[key], request.get("params"))

        # Step 1: split. stratify=True keeps the same yes/no mix in the training and test parts.
        split = make_split(self.X[features], self.y, test_size, seed, stratify=True)
        return self._fit_classifier(key, params, features, split, seed)

    def _fit_classifier(self, key, params, features, split, seed) -> dict:
        spec = clf.SPECS[key]

        # Step 2: build the pipeline (data preparation + classifier).
        pipeline = clf.build_pipeline(key, params, features, seed)

        # Step 3: train on the training rows only.
        started = time.perf_counter()
        pipeline.fit(split.X_train, split.y_train)
        train_seconds = time.perf_counter() - started

        # Step 4: predict the test rows and score the predictions.
        y_pred = pipeline.predict(split.X_test)
        scores = clf.probability_of_yes(pipeline, split.X_test)  # chance of "yes" for each test customer
        report = classification_report(split.y_test, y_pred, labels=[0, 1], names=list(CLASS_LABELS))
        roc = roc_curve(split.y_test, scores)
        fpr, tpr = downsample_curve(roc["fpr"], roc["tpr"])

        yes = report["per_class"][1]  # scores for the "yes" class
        # Baseline: the accuracy you would get by always guessing the most common answer.
        most_common = int(split.y_train.mode().iloc[0])
        metrics = {
            "accuracy": report["accuracy"],
            "precision": yes["precision"],
            "recall": yes["recall"],
            "f1": yes["f1"],
            "roc_auc": roc["auc"],
            "train_accuracy": float(pipeline.score(split.X_train, split.y_train)),
            "baseline_accuracy": float(np.mean(split.y_test == most_common)),
        }

        # The first few test customers with their real and predicted answers.
        predictions = []
        for i, row_index in enumerate(split.X_test.index[:PREDICTION_ROWS]):
            predictions.append({
                "row": int(row_index) + 2,  # +2 = line number in bank.csv (header line + counting from 1)
                "actual": CLASS_LABELS[int(split.y_test.loc[row_index])],
                "predicted": CLASS_LABELS[int(y_pred[i])],
                "score": float(scores[i]),
            })

        details = clf.describe_model(key, pipeline, split.X_train, split.y_train, split.X_test, features,
                                     params, seed)
        schema = input_schema(features, split.X_train)

        # Step 5: keep the trained model for the "score a new customer" forms.
        self._store(TrainedModel("classification", key, spec.label, pipeline, features, schema, TARGET,
                                 {"accuracy": metrics["accuracy"], "f1": metrics["f1"]}, now()))

        return {
            "task": "classification", "model": key, "label": spec.label, "summary": spec.summary,
            "params": {k: list(v) if isinstance(v, tuple) else v for k, v in params.items()},
            "features": features,
            "split": _split_info(split, len(self.y), seed, stratified=True),
            "metrics": metrics, "report": report,
            "roc": {"fpr": fpr, "tpr": tpr, "auc": roc["auc"], "reason": roc.get("reason")},
            "details": details, "predictions": predictions, "schema": schema,
            "train_seconds": train_seconds,
        }

    def compare_classifiers(self, request) -> dict:
        """Train all 3 classifiers with their default settings on the SAME split, so the scores are fair."""
        features, test_size, seed = self._read_common_settings(request, FEATURES)
        split = make_split(self.X[features], self.y, test_size, seed, stratify=True)
        rows = []
        for key, spec in clf.SPECS.items():
            result = self._fit_classifier(key, validate_params(spec, {}), features, split, seed)
            rows.append({"model": key, "label": spec.label, **result["metrics"],
                         "train_seconds": result["train_seconds"], "roc": result["roc"]})
        return {"task": "classification", "features": features, "rows": rows,
                "split": {"train": int(len(split.y_train)), "test": int(len(split.y_test)), "random_state": seed}}

    # =================================================================================================
    # REGRESSION: train one regression model, or compare both
    # =================================================================================================

    def _read_regression_settings(self, request):
        if not isinstance(request, dict):
            raise ValidationError("Request body must be a JSON object")
        target = _require_choice(request.get("target"), NUMERIC_FEATURES, "target", "regression target")
        allowed = [f for f in FEATURES if f != target]  # the target can never also be an input
        features, test_size, seed = self._read_common_settings(request, allowed)
        return target, features, test_size, seed

    def train_regressor(self, request) -> dict:
        target, features, test_size, seed = self._read_regression_settings(request)
        key = _require_choice(request.get("model"), reg.SPECS, "model", "regression model")
        reg.check_features_for_model(key, features)
        params = validate_params(reg.SPECS[key], request.get("params"))

        # Step 1: split (no stratify, because the target is a number, not a class).
        split = make_split(self.X[features], self.X[target], test_size, seed, stratify=False)
        return self._fit_regressor(key, params, target, features, split, seed)

    def _fit_regressor(self, key, params, target, features, split, seed) -> dict:
        spec = reg.SPECS[key]

        # Step 2 and 3: build the pipeline and train it on the training rows.
        pipeline = reg.build_pipeline(key, params, features)
        started = time.perf_counter()
        pipeline.fit(split.X_train, split.y_train)
        train_seconds = time.perf_counter() - started

        # Step 4: predict and score both the test rows and the training rows.
        test_pred = pipeline.predict(split.X_test)
        metrics = {"test": regression_metrics(split.y_test, test_pred),
                   "train": regression_metrics(split.y_train, pipeline.predict(split.X_train))}

        # Chart data: actual vs predicted for a sample of test rows.
        actual = split.y_test.to_numpy(dtype=float)
        picked = _pick_rows_for_chart(len(actual), MAX_PLOT_POINTS, seed)
        charts = {"points": [{"actual": float(actual[i]), "predicted": float(test_pred[i])} for i in picked],
                  "sampled": int(len(picked)), "total": int(len(actual))}

        # With one numeric input we can also draw the fitted line itself.
        if len(features) == 1 and features[0] in NUMERIC_FEATURES:
            x = split.X_test[features[0]].to_numpy(dtype=float)
            line_x = np.linspace(x.min(), x.max(), 120)
            line_y = pipeline.predict(pd.DataFrame({features[0]: line_x}))
            charts["fit"] = {"feature": features[0], "x": [float(x[i]) for i in picked],
                             "y": [float(actual[i]) for i in picked],
                             "line_x": line_x.tolist(), "line_y": [float(v) for v in line_y]}

        predictions = []
        for i, row_index in enumerate(split.X_test.index[:PREDICTION_ROWS]):
            real = float(split.y_test.loc[row_index])
            predictions.append({"row": int(row_index) + 2, "actual": real, "predicted": float(test_pred[i]),
                                "residual": real - float(test_pred[i])})

        details = reg.describe_model(key, pipeline, split.X_train, split.y_train, split.X_test, target)
        schema = input_schema(features, split.X_train)

        # Step 5: keep the trained model for the prediction form.
        self._store(TrainedModel("regression", key, spec.label, pipeline, features, schema, target,
                                 {"r2": metrics["test"]["r2"], "rmse": metrics["test"]["rmse"]}, now()))

        return {
            "task": "regression", "model": key, "label": spec.label, "summary": spec.summary,
            "params": params, "target": target, "target_label": FEATURE_INFO[target]["label"],
            "target_unit": FEATURE_INFO[target].get("unit"), "features": features,
            "split": _split_info(split, len(self.y), seed, stratified=False),
            "metrics": metrics, "charts": charts, "details": details, "predictions": predictions,
            "schema": schema, "train_seconds": train_seconds,
        }

    def compare_regressors(self, request) -> dict:
        """Train both regression models on the SAME split.

        Simple linear regression can only use one numeric input, so it gets the one that is most closely
        related to the target in the training rows.
        """
        target, features, test_size, seed = self._read_regression_settings(request)
        split = make_split(self.X[features], self.X[target], test_size, seed, stratify=False)
        numeric = [f for f in features if f in NUMERIC_FEATURES]
        rows, skipped = [], []

        for key, spec in reg.SPECS.items():
            used, note = features, None
            if key == "simple_linear":
                if not numeric:
                    skipped.append({"model": key, "label": spec.label, "reason": "No numeric feature selected"})
                    continue
                strength = {f: abs(split.X_train[f].corr(split.y_train)) for f in numeric}
                used = [max(strength, key=lambda f: np.nan_to_num(strength[f]))]
                note = f"x = {used[0]} (strongest link to the target)"
            try:
                reg.check_features_for_model(key, used)
            except ValidationError as exc:
                skipped.append({"model": key, "label": spec.label, "reason": str(exc)})
                continue

            subset = Split(split.X_train[used], split.X_test[used], split.y_train, split.y_test)
            result = self._fit_regressor(key, validate_params(spec, {}), target, used, subset, seed)
            rows.append({"model": key, "label": spec.label, "features_used": used, "note": note,
                         **result["metrics"]["test"], "train_r2": result["metrics"]["train"]["r2"],
                         "train_seconds": result["train_seconds"]})

        return {"task": "regression", "target": target, "features": features, "rows": rows, "skipped": skipped,
                "split": {"train": int(len(split.y_train)), "test": int(len(split.y_test)), "random_state": seed}}

    # =================================================================================================
    # PREDICTION for one new customer
    # =================================================================================================

    def predict(self, request) -> dict:
        if not isinstance(request, dict):
            raise ValidationError("Request body must be a JSON object")
        task = _require_choice(request.get("task"), ("classification", "regression"), "task", "task")
        key = request.get("model")
        trained = self.get_model(task, key)
        if trained is None:
            raise ValidationError(f"No trained {task} model '{key}'. Train it first.", "model")
        return trained.predict(request.get("values"))

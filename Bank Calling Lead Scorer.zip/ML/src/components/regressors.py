"""REGRESSION MODELS: predict a number (for example a customer's age) instead of yes/no.

This file holds both regression models. Each one has its own section below, marked with a banner like
    # REGRESSION 1: SIMPLE LINEAR REGRESSION

Order of the sections:
    1. Simple Linear Regression     (one input, a straight line)
    2. Multiple Linear Regression   (many inputs, each with its own weight)
"""

from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline

from src.components.data_transform import build_preprocessor, split_columns
from src.components.model_params import ModelSpec
from src.exception import ValidationError


# =====================================================================================================
# REGRESSION 1: SIMPLE LINEAR REGRESSION
# Fits the best straight line through ONE numeric input.
# =====================================================================================================

SIMPLE_LINEAR = ModelSpec(
    "simple_linear", "Simple Linear Regression",
    "Draws the best straight line through one numeric input.")


def make_simple_linear(features, params):
    # Numbers are left in their own units, so the result reads as "per one year", "per one unit" etc.
    preprocess = build_preprocessor(features, scaling=None, drop_first=True)
    return Pipeline([("preprocess", preprocess), ("model", LinearRegression())])


# =====================================================================================================
# REGRESSION 2: MULTIPLE LINEAR REGRESSION
# Same idea as simple linear regression, but with several inputs at once.
# =====================================================================================================

MULTIPLE_LINEAR = ModelSpec(
    "multiple_linear", "Multiple Linear Regression",
    "Combines several inputs, each with its own weight, into one prediction.")


def make_multiple_linear(features, params):
    # drop_first=True: for each category one level is left out as the "reference" level.
    # Without this, linear regression would have one column too many and could not pick unique weights.
    preprocess = build_preprocessor(features, scaling=None, drop_first=True)
    return Pipeline([("preprocess", preprocess), ("model", LinearRegression())])


# =====================================================================================================
# LOOK-UP TABLES used by the rest of the app
# =====================================================================================================

SPECS = {spec.key: spec for spec in [SIMPLE_LINEAR, MULTIPLE_LINEAR]}

MAKERS = {
    "simple_linear": make_simple_linear,
    "multiple_linear": make_multiple_linear,
}


# =====================================================================================================
# BUILDING AND DESCRIBING A REGRESSION MODEL
# =====================================================================================================

def check_features_for_model(key, features):
    """Each model has simple rules about which inputs it accepts."""
    numeric, _ = split_columns(features)
    if key == "simple_linear" and (len(features) != 1 or len(numeric) != 1):
        raise ValidationError("Simple linear regression uses exactly one numeric feature", "features")
    if key == "multiple_linear" and len(features) < 2:
        raise ValidationError("Multiple linear regression needs at least two features", "features")


def build_pipeline(key, params, features):
    """Create the data preparation + model pipeline for one regression model."""
    if key not in MAKERS:
        raise KeyError(f"Unknown regression model '{key}'")
    return MAKERS[key](features, params)


def describe_model(key, pipeline, X_train, y_train, X_test, target):
    """The weight learned for each input, shown as "Most influential inputs"."""
    model = pipeline.named_steps["model"]
    names = pipeline.named_steps["preprocess"].get_feature_names_out()
    coefficients = [{"term": str(name).split("__", 1)[-1], "coefficient": float(value)}
                    for name, value in zip(names, model.coef_.ravel())]
    return {"intercept": float(model.intercept_), "coefficients": coefficients}

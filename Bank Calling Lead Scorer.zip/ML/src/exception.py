"""Custom exceptions shared by the components, pipelines and API."""


class DatasetError(ValueError):
    """Raised when a dataset does not match the expected bank marketing schema."""


class ValidationError(ValueError):
    """Raised for invalid user input; `field` names the offending input when known."""

    def __init__(self, message: str, field: str | None = None):
        super().__init__(message)
        self.field = field


class ModelNotFoundError(FileNotFoundError):
    """Raised when a saved model artifact is missing; run the train pipeline first."""

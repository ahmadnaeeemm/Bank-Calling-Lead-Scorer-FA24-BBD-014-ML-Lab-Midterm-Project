"""Logging: prints progress messages (e.g. "Training Random Forest") to the terminal."""

import logging

_configured = False


def get_logger(name: str) -> logging.Logger:
    """Return a logger that prints messages with the time, e.g. get_logger(__name__)."""
    global _configured
    if not _configured:
        console = logging.StreamHandler()
        console.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
        root = logging.getLogger("src")
        root.setLevel(logging.INFO)
        root.addHandler(console)
        _configured = True
    return logging.getLogger(name if name.startswith("src") else f"src.{name}")

"""Orchestration pipelines: training end to end and inference with saved models."""

"""PREDICT PIPELINE: use a saved model to predict new customers from the command line.

Steps:
    1. Load the saved model file from models/ (made by the train pipeline)
    2. Read the customer(s): a CSV file (--input) or one customer as JSON (--values)
    3. Predict and print (or save) the results

Examples (from the project root):
  python -m src.pipelines.predict_pipeline --model logistic_regression --input data/processed/test.csv
  python -m src.pipelines.predict_pipeline --model random_forest --values "{\"age\": 38, \"job\": \"management\", ...}"
"""

import argparse
import json
from pathlib import Path

import pandas as pd

from src.components.model_trainer import MODEL_SUFFIX, TrainedModel, load_model
from src.exception import ModelNotFoundError, ValidationError
from src.logger import get_logger
from src.utils import load_config, project_path

log = get_logger(__name__)
TASKS = ("classification", "regression")


class PredictPipeline:
    """Loads saved models on demand and predicts with their fitted preprocessing."""

    def __init__(self, models_dir: Path | None = None):
        self.models_dir = models_dir or project_path(load_config()["artifacts"]["models_dir"])
        self._cache: dict[tuple[str, str], TrainedModel] = {}

    def available(self) -> list[str]:
        return sorted(p.stem for p in self.models_dir.glob(f"*{MODEL_SUFFIX}"))

    def load(self, task: str, model: str) -> TrainedModel:
        if task not in TASKS:
            raise ValidationError(f"Task must be one of {list(TASKS)}", "task")
        if (task, model) not in self._cache:
            self._cache[(task, model)] = load_model(self.models_dir / f"{task}__{model}{MODEL_SUFFIX}")
        return self._cache[(task, model)]

    def predict(self, task: str, model: str, records: list[dict]) -> list[dict]:
        trained = self.load(task, model)
        return [trained.predict(record) for record in records]

    def predict_frame(self, task: str, model: str, frame: pd.DataFrame) -> pd.DataFrame:
        """Score every row; columns the model does not use (e.g. deposit, duration) are ignored."""
        trained = self.load(task, model)
        missing = [f for f in trained.features if f not in frame.columns]
        if missing:
            raise ValidationError(f"Input is missing columns used by {trained.label}: {missing}", missing[0])
        records = frame[trained.features].to_dict(orient="records")
        results = [trained.predict(record) for record in records]
        out = frame.copy()
        out["predicted"] = [r["predicted"] for r in results]
        if task == "classification":
            out["probability_yes"] = [r["score"] for r in results]
        return out


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Score customers with a saved model.")
    parser.add_argument("--task", choices=TASKS, default="classification")
    parser.add_argument("--model", required=True, help="Model key, e.g. logistic_regression, random_forest, multiple_linear")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--input", type=Path, help="CSV file with one customer per row")
    source.add_argument("--values", help="One customer as a JSON object")
    parser.add_argument("--output", type=Path, help="Where to write the scored CSV (with --input)")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    """Command-line entry point; bad input or a missing model exits with a one-line error."""
    try:
        run_cli(parse_args(argv))
    except (ValidationError, ModelNotFoundError) as exc:
        raise SystemExit("Error: " + str(exc)) from None


def run_cli(args: argparse.Namespace) -> None:
    pipeline = PredictPipeline()
    if args.values is not None:
        try:
            values = json.loads(args.values)
        except json.JSONDecodeError as exc:
            raise SystemExit("--values must be valid JSON: " + str(exc)) from None
        result = pipeline.predict(args.task, args.model, [values])[0]
        print("Model:", result["label"])
        print("Predicted value:", result["predicted"])
        if args.task == "classification":
            print("Chance of yes:", round(result["score"], 4))
        for warning in result["warnings"]:
            print("Warning:", warning)
        return
    if not args.input.is_file():
        raise SystemExit("Input file not found: " + str(args.input))
    scored = pipeline.predict_frame(args.task, args.model, pd.read_csv(args.input))
    print("Scored rows:", len(scored))
    print(scored["predicted"].value_counts().to_string())
    if args.output:
        scored.to_csv(args.output, index=False)
        print("Saved predictions to", args.output)
    log.info("Scored %d rows from %s with %s", len(scored), args.input, args.model)


if __name__ == "__main__":
    main()

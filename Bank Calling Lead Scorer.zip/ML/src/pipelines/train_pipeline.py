"""TRAIN PIPELINE: train every model once and save the results.

Steps:
    1. Load bank.csv
    2. Save a clean copy of the data and the train/test split (data/interim, data/processed)
    3. Train and compare all 3 classifiers
    4. Train and compare both regression models
    5. Save every trained model (models/) and the score tables (reports/)

Run from the project root:  python -m src.pipelines.train_pipeline
"""

import pandas as pd

from src.components.data_ingestion import CLASS_LABELS, LEAKY_COLUMNS, TARGET
from src.components.data_transform import make_split
from src.components.model_trainer import ExperimentService
from src.logger import get_logger
from src.utils import load_config, project_path, save_json

log = get_logger(__name__)
CLASSIFICATION_COLUMNS = ["label", "accuracy", "precision", "recall", "f1", "roc_auc", "train_accuracy",
                          "baseline_accuracy", "train_seconds"]
REGRESSION_COLUMNS = ["label", "features_used", "r2", "mae", "mse", "rmse", "train_r2", "train_seconds"]


def write_datasets(service: ExperimentService, config: dict) -> dict:
    """Save the leak-free dataset (interim) and the default train/test split (processed).

    Values stay unscaled: scaling and encoding are fitted inside each model pipeline on training rows only.
    """
    interim = project_path(config["data"]["interim_path"])
    interim.parent.mkdir(parents=True, exist_ok=True)
    service.raw.drop(columns=LEAKY_COLUMNS).to_csv(interim, index=False)
    split = make_split(service.X, service.y, config["split"]["test_size"], config["split"]["random_state"],
                       stratify=True)
    processed = project_path(config["data"]["processed_dir"])
    processed.mkdir(parents=True, exist_ok=True)
    paths = {"interim": interim}
    for name, X, y in (("train", split.X_train, split.y_train), ("test", split.X_test, split.y_test)):
        frame = X.assign(**{TARGET: y.map(dict(enumerate(CLASS_LABELS)))})
        paths[name] = processed / f"{name}.csv"
        frame.to_csv(paths[name], index_label="source_row")
    return paths


def run(config: dict | None = None) -> dict:
    config = config or load_config()
    split_settings = {"test_size": config["split"]["test_size"], "random_state": config["split"]["random_state"]}

    # Step 1: load the data
    service = ExperimentService(project_path(config["data"]["raw_path"]))
    log.info("Loaded %d rows from %s", len(service.raw), config["data"]["raw_path"])

    # Step 2: save the clean data and the train/test split
    data_paths = write_datasets(service, config)

    # Step 3: CLASSIFICATION - train and compare all 3 classifiers
    classification = service.compare_classifiers(split_settings)

    # Step 4: REGRESSION - train and compare both regression models
    regression = service.compare_regressors({**split_settings, "target": config["regression"]["default_target"],
                                             "features": config["regression"]["default_features"]})

    # Step 5: save the trained models and the score tables
    model_paths = service.save_models(project_path(config["artifacts"]["models_dir"]))
    log.info("Saved %d models", len(model_paths))

    reports = project_path(config["artifacts"]["reports_dir"])
    reports.mkdir(parents=True, exist_ok=True)
    classification_table = pd.DataFrame(classification["rows"])[CLASSIFICATION_COLUMNS]
    regression_table = pd.DataFrame(regression["rows"])[REGRESSION_COLUMNS]
    classification_table.to_csv(reports / "classification_comparison.csv", index=False)
    regression_table.to_csv(reports / "regression_comparison.csv", index=False)
    save_json({"split": classification["split"], "features": classification["features"],
               "classification": classification_table.to_dict(orient="records"),
               "regression_target": regression["target"], "regression": regression_table.to_dict(orient="records"),
               "regression_skipped": regression["skipped"]}, reports / "metrics.json")
    return {"classification": classification_table, "regression": regression_table,
            "data_paths": data_paths, "model_paths": model_paths, "reports_dir": reports,
            "regression_target": regression["target"], "test_rows": classification["split"]["test"]}


def main() -> None:
    summary = run()
    print("Classification of deposit on", summary["test_rows"], "test rows")
    for row in summary["classification"].itertuples():
        print(row.label, "| Accuracy:", round(row.accuracy, 4), "| Precision:", round(row.precision, 4),
              "| Recall:", round(row.recall, 4), "| F1:", round(row.f1, 4), "| ROC-AUC:", round(row.roc_auc, 4))
    print()
    print("Regression of", summary["regression_target"], "(supplementary task)")
    for row in summary["regression"].itertuples():
        print(row.label, "| R2:", round(row.r2, 4), "| MAE:", round(row.mae, 3), "| RMSE:", round(row.rmse, 3))
    print()
    print("Models saved:", len(summary["model_paths"]), "files in", summary["model_paths"][0].parent)
    print("Reports saved in", summary["reports_dir"])
    print("Train/test data saved in", summary["data_paths"]["train"].parent)


if __name__ == "__main__":
    main()

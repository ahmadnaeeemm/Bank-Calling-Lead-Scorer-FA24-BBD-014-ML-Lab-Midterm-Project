"""Shared helpers: project paths, configuration, and saving/loading artifacts."""

import json
from functools import lru_cache
from pathlib import Path

import joblib
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = PROJECT_ROOT / "configs" / "config.yaml"
REQUIRED_SECTIONS = ("data", "split", "artifacts", "regression", "server")


@lru_cache(maxsize=None)
def load_config(path: Path = CONFIG_PATH) -> dict:
    """Read the YAML configuration and check that every section is present."""
    if not path.is_file():
        raise FileNotFoundError(f"Configuration file not found: {path}")
    with path.open(encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration must be a mapping: {path}")
    missing = [s for s in REQUIRED_SECTIONS if s not in config]
    if missing:
        raise ValueError(f"Configuration {path.name} is missing sections: {missing}")
    return config


def project_path(relative: str) -> Path:
    """Resolve a config path against the project root (keeps paths OS-independent)."""
    return PROJECT_ROOT / Path(relative)


def save_object(obj: object, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(obj, path)
    return path


def load_object(path: Path) -> object:
    """Load a joblib artifact written by this project (never load files from untrusted sources)."""
    if not path.is_file():
        raise FileNotFoundError(f"Artifact not found: {path}")
    return joblib.load(path)


def save_json(data: object, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path

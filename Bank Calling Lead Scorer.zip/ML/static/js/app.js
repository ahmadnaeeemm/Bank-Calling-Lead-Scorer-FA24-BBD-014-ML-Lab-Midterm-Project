/* FRONTEND LOGIC for the Lead Scoring Workbench.
 *
 * This file makes the web page work. It talks to the FastAPI backend (app.py) with fetch() and draws the results.
 * Sections, in order:
 *   1. Talking to the backend (api)
 *   2. Small helpers (number formatting, tabs, busy buttons, errors, forms)
 *   3. LEAD EVALUATOR tab   – score one customer with a trained classifier
 *   4. CLASSIFICATION tab   – train / compare the 3 classifiers
 *   5. REGRESSION tab       – train / compare the 2 regression models
 *   6. DATASET tab          – summary of bank.csv
 *   7. Start-up
 */
(function () {
  "use strict";

  const esc = Charts.escapeHtml;
  const state = { catalog: null, trained: [], datasetLoaded: false, evaluatorValues: {} };
  const GROUP_TITLES = {
    demographics: "Customer demographics",
    financial: "Financial standing & history",
    campaign: "Campaign contact plan",
  };
  const TEST_SIZES = [0.1, 0.2, 0.25, 0.3, 0.4, 0.5];

  // =============================================================================================
  // 1. TALKING TO THE BACKEND
  // =============================================================================================

  class ApiError extends Error {
    constructor(message, field) { super(message); this.field = field; }
  }

  /** GET a URL, or POST `body` as JSON when it is given. Returns the JSON answer. */
  async function api(path, body) {
    const options = body === undefined ? {} : {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    };
    let response;
    try {
      response = await fetch(path, options);
    } catch (err) {
      throw new ApiError("Could not reach the server. Is app.py still running?");
    }
    let data = null;
    try { data = await response.json(); } catch (err) { /* handled below */ }
    if (!response.ok) {
      throw new ApiError((data && data.error) || `Request failed with status ${response.status}`, data && data.field);
    }
    if (data === null) throw new ApiError("The server returned an unreadable response.");
    return data;
  }

  // =============================================================================================
  // 2. SMALL HELPERS
  // =============================================================================================

  // Number formatting
  const pct = (v) => (v === null || v === undefined ? "—" : `${(v * 100).toFixed(1)}%`);
  const dec = (v, d = 3) => (v === null || v === undefined ? "—" : Number(v).toFixed(d));
  const num = (v, d = 2) => (v === null || v === undefined ? "—" : Number(v).toLocaleString(undefined, { maximumFractionDigits: d }));
  const time = (iso) => new Date(iso).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const yesNoTag = (v) => `<span class="tag tag-${v === "yes" ? "yes" : "no"}">${esc(v)}</span>`;

  // Tabs at the top of the page (also work with the arrow keys)
  function setupTabs() {
    const tabs = Array.from(document.querySelectorAll(".tab"));
    function activate(tab, focus) {
      tabs.forEach((t) => {
        const selected = t === tab;
        t.setAttribute("aria-selected", String(selected));
        t.tabIndex = selected ? 0 : -1;
        document.getElementById(t.getAttribute("aria-controls")).hidden = !selected;
      });
      if (focus) tab.focus();
      if (tab.id === "tab-dataset" && !state.datasetLoaded) loadDataset();
      if (tab.id === "tab-evaluator") refreshTrained();
    }
    tabs.forEach((tab, i) => {
      tab.addEventListener("click", () => activate(tab, false));
      tab.addEventListener("keydown", (e) => {
        const step = { ArrowRight: 1, ArrowLeft: -1 }[e.key];
        if (step) { e.preventDefault(); activate(tabs[(i + step + tabs.length) % tabs.length], true); }
        if (e.key === "Home") { e.preventDefault(); activate(tabs[0], true); }
        if (e.key === "End") { e.preventDefault(); activate(tabs[tabs.length - 1], true); }
      });
    });
  }

  /** Disable the buttons and show a spinner while `task` runs. */
  async function withBusy(buttons, region, busyLabel, task) {
    const originals = buttons.map((b) => b.innerHTML);
    buttons.forEach((b) => { b.disabled = true; });
    buttons[0].innerHTML = `<span class="spinner" aria-hidden="true"></span>${esc(busyLabel)}`;
    buttons[0].setAttribute("aria-busy", "true");
    if (region) region.classList.add("is-busy");
    try {
      return await task();
    } finally {
      buttons.forEach((b, i) => { b.disabled = false; b.innerHTML = originals[i]; b.removeAttribute("aria-busy"); });
      if (region) region.classList.remove("is-busy");
    }
  }

  // Error messages (the field with the problem is highlighted)
  function clearErrors(scope, errorBox) {
    scope.querySelectorAll('[aria-invalid="true"]').forEach((el) => el.removeAttribute("aria-invalid"));
    if (errorBox) errorBox.innerHTML = "";
  }

  function showError(errorBox, scope, error) {
    errorBox.innerHTML = `<div class="alert alert-error">${esc(error.message)}</div>`;
    if (!error.field || !scope) return;
    const target = scope.querySelector(`[data-field="${CSS.escape(error.field)}"], [data-param="${CSS.escape(error.field)}"]`);
    if (target) { target.setAttribute("aria-invalid", "true"); target.focus(); }
  }

  // Model settings boxes (built from the settings list the backend sends)
  function renderParams(container, spec) {
    if (!spec.params.length) {
      container.innerHTML = '<p class="meta span-2">This model has no settings to change.</p>';
      return;
    }
    container.innerHTML = spec.params.map((p) => {
      const id = `${container.id}-${p.name}`;
      let control;
      if (p.kind === "choice") {
        control = `<select class="select" id="${id}" data-param="${p.name}">${p.options.map((o) =>
          `<option value="${esc(o)}"${String(o) === String(p.default) ? " selected" : ""}>${esc(o)}</option>`).join("")}</select>`;
      } else {
        const step = p.kind === "int" ? "1" : "any";
        const value = p.default === null ? "" : p.default;
        control = `<input class="input" id="${id}" data-param="${p.name}" type="number" step="${step}" inputmode="decimal" value="${esc(value)}"${p.nullable ? ' placeholder="No limit"' : ""}>`;
      }
      const hint = p.help ? `<span class="hint">${esc(p.help)}</span>` : "";
      return `<div class="field"><label for="${id}">${esc(p.label)}</label>${control}${hint}</div>`;
    }).join("");
  }

  function readParams(container) {
    const params = {};
    container.querySelectorAll("[data-param]").forEach((el) => { params[el.dataset.param] = el.value.trim(); });
    return params;
  }

  // Input feature check boxes
  function renderFeatureChecks(container, selected, disabled) {
    const info = state.catalog.feature_info;
    container.innerHTML = state.catalog.classification.features.map((name) => {
      const off = disabled && disabled.includes(name);
      return `<label class="check${off ? " is-disabled" : ""}"><input type="checkbox" value="${name}"${selected.includes(name) && !off ? " checked" : ""}${off ? " disabled" : ""}>` +
        `<span>${esc(info[name].label)} <span class="kind">${info[name].kind === "number" ? "number" : "category"}</span></span></label>`;
    }).join("");
  }

  const readFeatures = (container) =>
    Array.from(container.querySelectorAll("input:checked:not(:disabled)")).map((el) => el.value);

  function bindSelectLinks(form, container) {
    form.querySelectorAll("[data-select]").forEach((btn) => btn.addEventListener("click", () => {
      container.querySelectorAll("input:not(:disabled)").forEach((el) => { el.checked = btn.dataset.select === "all"; });
    }));
  }

  function fillTestSizes(sizeSelect) {
    const d = state.catalog.defaults;
    sizeSelect.innerHTML = TEST_SIZES.map((s) =>
      `<option value="${s}"${s === d.test_size ? " selected" : ""}>${s * 100}% of customers kept for testing</option>`).join("");
  }

  /** The form for one new customer, grouped into numbered sections. */
  function renderSampleForm(container, schema, prefix, values) {
    const groups = [];
    schema.forEach((f) => {
      let group = groups.find((g) => g.key === f.group);
      if (!group) { group = { key: f.group, fields: [] }; groups.push(group); }
      group.fields.push(f);
    });
    container.innerHTML = groups.map((g, gi) => {
      const fields = g.fields.map((f) => {
        const id = `${prefix}-${f.name}`;
        const current = values && values[f.name] !== undefined ? values[f.name] : f.default;
        const unit = f.unit ? ` <span class="unit">(${esc(f.unit)})</span>` : "";
        let control;
        if (f.kind === "category") {
          control = `<select class="select" id="${id}" data-field="${f.name}" title="${esc(f.description)}">${f.options.map((o) =>
            `<option value="${esc(o.value)}"${o.value === current ? " selected" : ""}>${esc(o.label)}</option>`).join("")}</select>`;
        } else {
          control = `<input class="input" id="${id}" data-field="${f.name}" type="number" step="1" inputmode="numeric" value="${esc(current)}" title="${esc(f.description)}">`;
        }
        return `<div class="field"><label for="${id}">${esc(f.label)}${unit}</label>${control}</div>`;
      }).join("");
      return `<p class="section-label">${gi + 1}. ${esc(GROUP_TITLES[g.key] || g.key)}</p><div class="grid-2">${fields}</div>`;
    }).join("");
  }

  function readSample(container, schema) {
    const values = {};
    for (const f of schema) {
      const el = container.querySelector(`[data-field="${f.name}"]`);
      if (f.kind === "number") {
        const raw = el.value.trim();
        if (raw === "" || !Number.isFinite(Number(raw))) throw new ApiError(`${f.label} needs a number.`, f.name);
        values[f.name] = Number(raw);
      } else {
        values[f.name] = el.value;
      }
    }
    return values;
  }

  /** The result card for one prediction. */
  function renderPrediction(result) {
    const warnings = result.warnings.length
      ? `<div class="alert alert-warning">Please check:<ul>${result.warnings.map((w) => `<li>${esc(w)}</li>`).join("")}</ul></div>` : "";

    // Regression: show the predicted number.
    if (result.task === "regression") {
      const unit = result.unit ? ` ${esc(result.unit)}` : "";
      return `<div class="outcome"><p class="eyebrow">Prediction · ${esc(result.label)}</p>` +
        `<p class="outcome-title">${esc(result.target_label)}: ${num(result.predicted, 1)}${unit}</p>` +
        `<p class="meta">Model R² on test customers: ${dec(result.headline.r2, 2)}</p>${warnings}</div>`;
    }

    // Classification: show yes/no and the chance of "yes" (the model says "yes" at 50% or more).
    const yes = result.predicted === "yes";
    const title = yes ? "Likely to subscribe" : "Unlikely to subscribe";
    const p = Math.min(1, Math.max(0, result.score));
    const score = `<div class="meter" role="img" aria-label="Chance of subscribing ${pct(p)}"><span class="meter-fill" style="width:${p * 100}%"></span>` +
      `<span class="meter-threshold" style="left:50%"></span></div>` +
      `<div class="meter-scale"><span>0%</span><span>50%</span><span>100%</span></div>` +
      `<p class="meta">Chance of subscribing: <strong>${pct(p)}</strong></p>`;
    return `<div class="outcome"><p class="eyebrow">Prediction · ${esc(result.label)}</p>` +
      `<p class="outcome-title${yes ? " yes" : ""}">${title}</p>${score}` +
      `<p class="meta">Model accuracy on test customers: ${pct(result.headline.accuracy)}</p>${warnings}</div>`;
  }

  /** A "score a new customer" form tied to one trained model. */
  function attachSampleScorer(root, task, model, schema) {
    const fields = root.querySelector("[data-sample-fields]");
    const button = root.querySelector("[data-sample-submit]");
    const out = root.querySelector("[data-sample-result]");
    const errorBox = root.querySelector("[data-sample-error]");
    renderSampleForm(fields, schema, `${task}-sample`);
    root.querySelector("form").addEventListener("submit", async (e) => {
      e.preventDefault();
      clearErrors(fields, errorBox);
      try {
        const values = readSample(fields, schema);
        const result = await withBusy([button], null, "Predicting…", () => api("/api/predict", { task, model, values }));
        out.innerHTML = renderPrediction(result);
      } catch (err) {
        showError(errorBox, fields, err);
      }
    });
  }

  const sampleBlock = (title, buttonLabel) =>
    `<div data-sample><h3>${esc(title)}</h3><form novalidate><div data-sample-fields></div>` +
    `<div class="actions" style="margin-top:24px"><button type="submit" class="btn btn-secondary" data-sample-submit>${esc(buttonLabel)}</button></div>` +
    '<div data-sample-error role="alert"></div></form><div data-sample-result aria-live="polite"></div></div>';

  /** A row of headline numbers. items: [{label, value, sub}] */
  function statsBlock(items) {
    return `<dl class="stats">${items.map((s) =>
      `<div class="stat"><dt>${esc(s.label)}</dt><dd>${s.value}</dd>${s.sub ? `<span class="sub">${s.sub}</span>` : ""}</div>`).join("")}</dl>`;
  }

  // =============================================================================================
  // 3. LEAD EVALUATOR TAB
  // =============================================================================================

  async function refreshTrained() {
    try {
      state.trained = (await api("/api/models/trained")).models;
    } catch (err) {
      document.getElementById("evaluator-error").innerHTML = `<div class="alert alert-error">${esc(err.message)}</div>`;
      return;
    }
    renderEvaluatorModels();
  }

  function renderEvaluatorModels() {
    const select = document.getElementById("evaluator-model");
    const order = state.catalog.classification.models.map((m) => m.key);
    const classifiers = state.trained.filter((m) => m.task === "classification")
      .sort((a, b) => order.indexOf(a.model) - order.indexOf(b.model));
    const previous = select.value;
    const submit = document.getElementById("evaluator-submit");
    if (!classifiers.length) {
      select.innerHTML = "<option>No trained classifier</option>";
      select.disabled = true;
      submit.disabled = true;
      document.getElementById("evaluator-model-meta").textContent = "";
      document.getElementById("evaluator-fields").innerHTML =
        '<div class="empty" style="margin-top:24px"><strong>No classifier is trained yet</strong>' +
        '<p>Train one in the Classification tab, or start with logistic regression.</p>' +
        '<button type="button" class="btn btn-secondary btn-small" id="evaluator-train-default" style="margin-top:16px">Train logistic regression</button></div>';
      document.getElementById("evaluator-train-default").addEventListener("click", async (e) => {
        try {
          await withBusy([e.currentTarget], null, "Training…", () => api("/api/classification/train", { model: "logistic_regression" }));
          await refreshTrained();
        } catch (err) {
          document.getElementById("evaluator-error").innerHTML = `<div class="alert alert-error">${esc(err.message)}</div>`;
        }
      });
      return;
    }
    select.disabled = false;
    submit.disabled = false;
    select.innerHTML = classifiers.map((m) => `<option value="${m.model}">${esc(m.label)}</option>`).join("");
    if (classifiers.some((m) => m.model === previous)) select.value = previous;
    renderEvaluatorFields();
  }

  function selectedEvaluatorModel() {
    const key = document.getElementById("evaluator-model").value;
    return state.trained.find((m) => m.task === "classification" && m.model === key);
  }

  function renderEvaluatorFields() {
    const model = selectedEvaluatorModel();
    if (!model) return;
    const fields = document.getElementById("evaluator-fields");
    // Remember what was typed, so switching models does not clear the form.
    fields.querySelectorAll("[data-field]").forEach((el) => { state.evaluatorValues[el.dataset.field] = el.value; });
    renderSampleForm(fields, model.schema, "evaluator", state.evaluatorValues);
    document.getElementById("evaluator-model-meta").textContent = `Accuracy on test customers: ${pct(model.headline.accuracy)}`;
  }

  function setupEvaluator() {
    document.getElementById("evaluator-model").addEventListener("change", () => {
      renderEvaluatorFields();
      document.getElementById("evaluator-result").innerHTML = "";
    });
    document.getElementById("evaluator-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const model = selectedEvaluatorModel();
      const errorBox = document.getElementById("evaluator-error");
      const fields = document.getElementById("evaluator-fields");
      clearErrors(fields, errorBox);
      if (!model) return;
      try {
        const values = readSample(fields, model.schema);
        const result = await withBusy([document.getElementById("evaluator-submit")], null, "Evaluating…",
          () => api("/api/predict", { task: "classification", model: model.model, values }));
        document.getElementById("evaluator-result").innerHTML = renderPrediction(result);
      } catch (err) {
        showError(errorBox, fields, err);
      }
    });
  }

  // =============================================================================================
  // 4. CLASSIFICATION TAB (3 classifiers – backend code in src/components/classifiers.py)
  // =============================================================================================

  function setupClassification() {
    const c = state.catalog.classification;
    const modelSelect = document.getElementById("cls-model");
    modelSelect.innerHTML = c.models.map((m) => `<option value="${m.key}">${esc(m.label)}</option>`).join("");
    const onModel = () => {
      const spec = c.models.find((m) => m.key === modelSelect.value);
      document.getElementById("cls-model-summary").textContent = spec.summary;
      renderParams(document.getElementById("cls-params"), spec);
    };
    modelSelect.addEventListener("change", onModel);
    onModel();
    const features = document.getElementById("cls-features");
    renderFeatureChecks(features, c.features);
    const form = document.getElementById("cls-form");
    bindSelectLinks(form, features);
    fillTestSizes(document.getElementById("cls-test-size"));

    const request = () => ({
      model: modelSelect.value,
      params: readParams(document.getElementById("cls-params")),
      features: readFeatures(features),
      test_size: document.getElementById("cls-test-size").value,
    });
    const results = document.getElementById("cls-results");
    const errorBox = document.getElementById("cls-error");
    const buttons = [document.getElementById("cls-train"), document.getElementById("cls-compare")];

    // "Train and Evaluate" button
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      clearErrors(form, errorBox);
      try {
        const result = await withBusy(buttons, results, "Training…", () => api("/api/classification/train", request()));
        renderClassificationResult(result);
        refreshTrained();
      } catch (err) {
        showError(errorBox, form, err);
      }
    });

    // "Compare All Classifiers" button
    buttons[1].addEventListener("click", async () => {
      clearErrors(form, errorBox);
      const { features: f, test_size } = request();
      try {
        const result = await withBusy([buttons[1], buttons[0]], results, `Training all ${state.catalog.classification.models.length} classifiers…`,
          () => api("/api/classification/compare", { features: f, test_size }));
        renderClassificationCompare(result);
        refreshTrained();
      } catch (err) {
        showError(errorBox, form, err);
      }
    });
  }

  /** One extra chart per model, where it helps explain what the model learned. */
  function classificationDetails(r) {
    const d = r.details;
    const name = (term) => term.replace(/_/g, " ");

    // Logistic regression: which inputs push the answer towards "yes" or "no"
    if (d.weights) {
      return `<h3>Most influential inputs</h3><p class="meta">Bars to the right push towards "yes", bars to the left towards "no".</p>` +
        `<div style="margin-top:12px">${Charts.bars(d.weights.map((w) => ({ label: name(w.term), value: w.weight })), { signed: true, format: (v) => v.toFixed(2) })}</div>`;
    }
    // Decision tree and random forest: which inputs the trees used most
    if (d.importances) {
      const size = d.trees ? `${d.trees} trees` : `Tree depth ${d.depth} · ${d.leaves} leaves`;
      return `<h3>Most important inputs</h3><p class="meta">${size}</p>` +
        `<div style="margin-top:12px">${Charts.bars(d.importances.map((w) => ({ label: name(w.term), value: w.importance })), { format: (v) => pct(v) })}</div>`;
    }
    return "";
  }

  function renderClassificationResult(r) {
    const m = r.metrics;
    const predictionRows = r.predictions.map((p) =>
      `<tr><td class="num">${p.row}</td><td>${yesNoTag(p.actual)}</td><td>${yesNoTag(p.predicted)}</td>` +
      `<td class="num">${pct(p.score)}</td>` +
      `<td>${p.actual === p.predicted ? "Correct" : '<span class="tag tag-wrong">Wrong</span>'}</td></tr>`).join("");
    const roc = r.roc.auc === null
      ? `<p class="meta">${esc(r.roc.reason)}</p>`
      : Charts.lineChart([{ label: "ROC", x: r.roc.fpr, y: r.roc.tpr }], { xLabel: "False positive rate", yLabel: "True positive rate", xDomain: [0, 1], yDomain: [0, 1], diagonal: true });
    const results = document.getElementById("cls-results");
    results.innerHTML = `<article class="card">
      <div class="result-head"><div><p class="eyebrow">Result</p><h2>${esc(r.label)}</h2>
      <p class="meta">Trained on ${r.split.train.toLocaleString()} customers, tested on ${r.split.test.toLocaleString()} · ${r.features.length} inputs</p></div></div>
      ${statsBlock([
        { label: "Accuracy", value: pct(m.accuracy), sub: "Customers predicted correctly" },
        { label: "Precision", value: pct(m.precision), sub: "Right when it says “yes”" },
        { label: "Recall", value: pct(m.recall), sub: "Subscribers it finds" },
        { label: "F1 score", value: dec(m.f1), sub: "Balance of precision and recall" },
        { label: "ROC-AUC", value: dec(m.roc_auc), sub: "Ranking quality (1.0 is perfect)" },
      ])}
      <div class="grid-2" style="margin-top:32px">
        <figure><figcaption>Confusion matrix<span class="meta">Test customers · actual vs predicted</span></figcaption>${Charts.confusion(r.report.confusion_matrix, r.report.labels)}</figure>
        <figure class="chart"><figcaption>ROC curve<span class="meta">Dashed line = random guessing</span></figcaption>${roc}</figure>
      </div>
      ${classificationDetails(r)}
      <h3>Sample predictions</h3>
      <p class="meta" style="margin-bottom:12px">First ${r.predictions.length} test customers.</p>
      <div class="table-wrap"><table><thead><tr><th class="num">Row</th><th>Actual</th><th>Predicted</th><th class="num">Chance of yes</th><th>Result</th></tr></thead><tbody>${predictionRows}</tbody></table></div>
      ${sampleBlock("Score a new customer", "Predict with this model")}
    </article>`;
    attachSampleScorer(results.querySelector("[data-sample]"), "classification", r.model, r.schema);
    results.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function renderClassificationCompare(r) {
    const bestF1 = Math.max(...r.rows.map((row) => row.f1));
    const rows = r.rows.map((row) => `<tr${row.f1 === bestF1 ? ' class="is-best"' : ""}><td>${esc(row.label)}</td>` +
      `<td class="num">${pct(row.accuracy)}</td><td class="num">${pct(row.precision)}</td><td class="num">${pct(row.recall)}</td>` +
      `<td class="num">${dec(row.f1)}</td><td class="num">${dec(row.roc_auc)}</td></tr>`).join("");
    const curves = r.rows.filter((row) => row.roc.auc !== null).map((row) => ({ label: row.label, x: row.roc.fpr, y: row.roc.tpr }));
    document.getElementById("cls-results").innerHTML = `<article class="card">
      <p class="eyebrow">Comparison</p><h2>All classifiers</h2>
      <p class="meta">Default settings · same ${r.split.train.toLocaleString()} training and ${r.split.test.toLocaleString()} test customers. The highlighted row has the best F1 score.</p>
      <div class="table-wrap" style="margin-top:20px"><table><thead><tr><th>Model</th><th class="num">Accuracy</th><th class="num">Precision</th><th class="num">Recall</th><th class="num">F1</th><th class="num">ROC-AUC</th></tr></thead><tbody>${rows}</tbody></table></div>
      <p class="footnote">Every model is now available in the Lead Evaluator tab.</p>
      <figure class="chart chart-narrow" style="margin-top:24px"><figcaption>ROC curves<span class="meta">Higher and further left is better</span></figcaption>
      ${Charts.lineChart(curves, { xLabel: "False positive rate", yLabel: "True positive rate", xDomain: [0, 1], yDomain: [0, 1], diagonal: true })}</figure>
    </article>`;
  }

  // =============================================================================================
  // 5. REGRESSION TAB (2 regression models – backend code in src/components/regressors.py)
  // =============================================================================================

  function setupRegression() {
    const g = state.catalog.regression;
    const form = document.getElementById("reg-form");
    const modelSelect = document.getElementById("reg-model");
    const targetSelect = document.getElementById("reg-target");
    const features = document.getElementById("reg-features");
    const hint = document.getElementById("reg-feature-hint");
    const info = state.catalog.feature_info;
    modelSelect.innerHTML = g.models.map((m) => `<option value="${m.key}">${esc(m.label)}</option>`).join("");
    modelSelect.value = "multiple_linear";
    targetSelect.innerHTML = g.targets.map((t) => `<option value="${t.name}">${esc(t.label)}${t.unit ? ` (${esc(t.unit)})` : ""}</option>`).join("");
    targetSelect.value = g.default_target;

    const numericOptions = () => g.features.filter((f) => info[f].kind === "number" && f !== targetSelect.value);

    // Simple linear regression takes exactly one numeric input, so the check boxes change with the model.
    function syncForModel() {
      const key = modelSelect.value;
      const spec = g.models.find((m) => m.key === key);
      document.getElementById("reg-model-summary").textContent = spec.summary;
      renderParams(document.getElementById("reg-params"), spec);
      if (key === "simple_linear") {
        const numeric = readFeatures(features).filter((f) => info[f].kind === "number");
        const keep = numeric.length ? numeric[0] : numericOptions()[0];
        renderFeatureChecks(features, [keep], [targetSelect.value]);
        hint.textContent = "Inputs: choose exactly one number input";
      } else {
        hint.textContent = key === "multiple_linear" ? "Inputs: choose two or more" : "Inputs";
      }
    }
    renderFeatureChecks(features, g.default_features, [g.default_target]);
    modelSelect.addEventListener("change", syncForModel);
    targetSelect.addEventListener("change", () => {
      renderFeatureChecks(features, readFeatures(features), [targetSelect.value]);
      if (modelSelect.value === "simple_linear") syncForModel();
    });
    features.addEventListener("change", (e) => {
      if (modelSelect.value !== "simple_linear" || !e.target.checked) return;
      features.querySelectorAll("input:checked").forEach((el) => { if (el !== e.target) el.checked = false; });
    });
    syncForModel();
    bindSelectLinks(form, features);
    fillTestSizes(document.getElementById("reg-test-size"));

    const request = () => ({
      model: modelSelect.value, target: targetSelect.value,
      params: readParams(document.getElementById("reg-params")), features: readFeatures(features),
      test_size: document.getElementById("reg-test-size").value,
    });
    const results = document.getElementById("reg-results");
    const errorBox = document.getElementById("reg-error");
    const buttons = [document.getElementById("reg-train"), document.getElementById("reg-compare")];

    // "Train and Evaluate" button
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      clearErrors(form, errorBox);
      try {
        const result = await withBusy(buttons, results, "Training…", () => api("/api/regression/train", request()));
        renderRegressionResult(result);
      } catch (err) {
        showError(errorBox, form, err);
      }
    });

    // "Compare Regression Models" button
    buttons[1].addEventListener("click", async () => {
      clearErrors(form, errorBox);
      const { target, features: f, test_size } = request();
      try {
        const result = await withBusy([buttons[1], buttons[0]], results, "Training both regression models…",
          () => api("/api/regression/compare", { target, features: f, test_size }));
        renderRegressionCompare(result);
      } catch (err) {
        showError(errorBox, form, err);
      }
    });
  }

  function regressionDetails(r) {
    const d = r.details;
    const top = d.coefficients.slice().sort((a, b) => Math.abs(b.coefficient) - Math.abs(a.coefficient)).slice(0, 10);
    return `<h3>Most influential inputs</h3><p class="meta">Bars to the right raise the prediction, bars to the left lower it.</p>` +
      `<div style="margin-top:12px">${Charts.bars(top.map((c) => ({ label: c.term.replace(/_/g, " "), value: c.coefficient })), { signed: true, format: (v) => v.toFixed(2) })}</div>`;
  }

  function renderRegressionResult(r) {
    const t = r.metrics.test;
    const unit = r.target_unit ? ` ${esc(r.target_unit)}` : "";
    const pts = r.charts.points;
    const fit = r.charts.fit
      ? `<figure class="chart"><figcaption>Fitted line<span class="meta">Orange line = the model</span></figcaption>
         ${Charts.scatterChart(r.charts.fit.x, r.charts.fit.y, { xLabel: state.catalog.feature_info[r.charts.fit.feature].label, yLabel: r.target_label, line: { x: r.charts.fit.line_x, y: r.charts.fit.line_y } })}</figure>` : "";
    const predictionRows = r.predictions.map((p) => `<tr><td class="num">${p.row}</td><td class="num">${num(p.actual, 1)}</td><td class="num">${num(p.predicted, 1)}</td></tr>`).join("");
    const results = document.getElementById("reg-results");
    results.innerHTML = `<article class="card">
      <div class="result-head"><div><p class="eyebrow">Result</p><h2>${esc(r.label)}: ${esc(r.target_label)}</h2>
      <p class="meta">Trained on ${r.split.train.toLocaleString()} customers, tested on ${r.split.test.toLocaleString()} · inputs: ${r.features.map((f) => esc(state.catalog.feature_info[f].label)).join(", ")}</p></div></div>
      ${statsBlock([
        { label: "R² score", value: dec(t.r2), sub: "Share of variation explained (1.0 is perfect)" },
        { label: "Average error (MAE)", value: num(t.mae) + unit, sub: "Lower is better" },
        { label: "RMSE", value: num(t.rmse) + unit, sub: "Lower is better" },
      ])}
      <div class="grid-2" style="margin-top:32px">
        <figure class="chart"><figcaption>Actual vs predicted<span class="meta">Dashed line = perfect prediction</span></figcaption>
          ${Charts.scatterChart(pts.map((p) => p.actual), pts.map((p) => p.predicted), { xLabel: `Actual ${r.target_label}`, yLabel: "Predicted", diagonal: true })}</figure>
        ${fit}
      </div>
      ${regressionDetails(r)}
      <h3>Sample predictions</h3>
      <p class="meta" style="margin-bottom:12px">First ${r.predictions.length} test customers.</p>
      <div class="table-wrap"><table><thead><tr><th class="num">Row</th><th class="num">Actual</th><th class="num">Predicted</th></tr></thead><tbody>${predictionRows}</tbody></table></div>
      ${sampleBlock("Predict for a new customer", "Predict with this model")}
    </article>`;
    attachSampleScorer(results.querySelector("[data-sample]"), "regression", r.model, r.schema);
    results.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function renderRegressionCompare(r) {
    const best = Math.max(...r.rows.map((row) => row.r2 ?? -Infinity));
    const label = state.catalog.feature_info[r.target].label;
    const rows = r.rows.map((row) => `<tr${row.r2 === best ? ' class="is-best"' : ""}><td>${esc(row.label)}</td><td class="wrap">${esc(row.note || `${row.features_used.length} inputs`)}</td>` +
      `<td class="num">${dec(row.r2)}</td><td class="num">${num(row.mae)}</td><td class="num">${num(row.rmse)}</td></tr>`).join("");
    const skipped = r.skipped.length
      ? `<div class="alert alert-info">Skipped: ${r.skipped.map((s) => `${esc(s.label)} (${esc(s.reason)})`).join("; ")}</div>` : "";
    document.getElementById("reg-results").innerHTML = `<article class="card">
      <p class="eyebrow">Comparison</p><h2>Regression models for ${esc(label)}</h2>
      <p class="meta">Default settings · same ${r.split.train.toLocaleString()} training and ${r.split.test.toLocaleString()} test customers. The highlighted row has the best R² score.</p>
      <div class="table-wrap" style="margin-top:20px"><table><thead><tr><th>Model</th><th>Inputs</th><th class="num">R²</th><th class="num">MAE</th><th class="num">RMSE</th></tr></thead><tbody>${rows}</tbody></table></div>
      ${skipped}
    </article>`;
  }

  // =============================================================================================
  // 6. DATASET TAB (backend code in src/components/data_ingestion.py)
  // =============================================================================================

  async function loadDataset() {
    const body = document.getElementById("dataset-body");
    try {
      const d = await api("/api/dataset");
      state.datasetLoaded = true;
      const yes = d.target_counts.yes;
      const columnRows = d.columns_info.map((c) => {
        const roleTag = c.role === "target" ? '<span class="tag tag-target">target</span>'
          : c.role === "dropped" ? '<span class="tag tag-dropped">not used</span>' : "input";
        return `<tr><td><strong>${esc(c.name)}</strong></td><td>${roleTag}</td><td>${c.kind === "numeric" ? "number" : "category"}</td><td class="wrap">${esc(c.description)}</td></tr>`;
      }).join("");
      const numericRows = d.numeric_summary.map((n) => `<tr><td>${esc(n.name)}</td><td class="num">${num(n.min)}</td><td class="num">${num(n.median)}</td><td class="num">${num(n.mean, 1)}</td><td class="num">${num(n.max)}</td></tr>`).join("");
      const rateOptions = state.catalog.classification.features.map((f) => `<option value="${f}"${f === "job" ? " selected" : ""}>${esc(state.catalog.feature_info[f].label)}</option>`).join("");
      body.innerHTML = `
        ${statsBlock([
          { label: "Customers", value: d.rows.toLocaleString() },
          { label: "Columns", value: d.columns, sub: `${d.features_used} used as inputs` },
          { label: "Missing values", value: d.missing_cells },
          { label: "Subscribed", value: pct(yes / d.rows), sub: `${yes.toLocaleString()} yes · ${d.target_counts.no.toLocaleString()} no` },
        ])}
        <div class="alert alert-info" style="margin-top:20px"><strong>Call duration is not used.</strong> It is only known after the call ends, so it would give the answer away.</div>
        <h3>Columns</h3>
        <div class="table-wrap"><table><thead><tr><th>Column</th><th>Role</th><th>Type</th><th>Meaning</th></tr></thead><tbody>${columnRows}</tbody></table></div>
        <h3>Subscription rate by input</h3>
        <div class="grid-2"><div class="field"><label for="rate-column">Input</label><select class="select" id="rate-column">${rateOptions}</select></div></div>
        <div id="rate-chart" style="margin-top:16px" aria-live="polite"></div>
        <p class="footnote">Share of customers who subscribed in each group. Number inputs are split into five groups.</p>
        <h3>Number columns</h3>
        <div class="table-wrap"><table><thead><tr><th>Column</th><th class="num">Min</th><th class="num">Median</th><th class="num">Average</th><th class="num">Max</th></tr></thead><tbody>${numericRows}</tbody></table></div>
        <h3>Raw rows</h3>
        <div id="preview"></div>`;
      const rateSelect = document.getElementById("rate-column");
      rateSelect.addEventListener("change", () => loadRates(rateSelect.value));
      loadRates("job");
      loadPreview(0);
    } catch (err) {
      body.innerHTML = `<div class="alert alert-error">Could not load the dataset summary: ${esc(err.message)}</div>`;
    }
  }

  async function loadRates(column) {
    const out = document.getElementById("rate-chart");
    out.classList.add("is-busy");
    try {
      const data = await api(`/api/dataset/rates?column=${encodeURIComponent(column)}`);
      out.innerHTML = Charts.bars(data.rates.map((r) => ({ label: `${r.group} (${r.count.toLocaleString()})`, value: r.rate })),
        { max: 1, format: (v) => pct(v) });
    } catch (err) {
      out.innerHTML = `<div class="alert alert-error">${esc(err.message)}</div>`;
    } finally {
      out.classList.remove("is-busy");
    }
  }

  async function loadPreview(offset) {
    const out = document.getElementById("preview");
    out.classList.add("is-busy");
    try {
      const page = await api(`/api/dataset/preview?offset=${offset}&limit=25`);
      const head = page.columns.map((c) => `<th>${esc(c)}</th>`).join("");
      const rows = page.rows.map((row, i) => `<tr><td class="num">${offset + i + 2}</td>${row.map((v) => `<td>${esc(v)}</td>`).join("")}</tr>`).join("");
      const last = Math.min(offset + page.rows.length, page.total);
      out.innerHTML = `<div class="table-wrap"><table><thead><tr><th class="num">Row</th>${head}</tr></thead><tbody>${rows}</tbody></table></div>
        <div class="pager"><span>Rows ${offset + 1}–${last} of ${page.total.toLocaleString()}</span>
        <button type="button" class="btn btn-secondary btn-small" id="preview-prev"${offset === 0 ? " disabled" : ""}>Previous</button>
        <button type="button" class="btn btn-secondary btn-small" id="preview-next"${last >= page.total ? " disabled" : ""}>Next</button></div>`;
      document.getElementById("preview-prev").addEventListener("click", () => loadPreview(Math.max(0, offset - 25)));
      document.getElementById("preview-next").addEventListener("click", () => loadPreview(offset + 25));
    } catch (err) {
      out.innerHTML = `<div class="alert alert-error">${esc(err.message)}</div>`;
    } finally {
      out.classList.remove("is-busy");
    }
  }

  // =============================================================================================
  // 7. START-UP: load the model list from the backend, then set up every tab
  // =============================================================================================

  async function init() {
    setupTabs();
    try {
      state.catalog = await api("/api/models");
    } catch (err) {
      document.querySelector("main").insertAdjacentHTML("afterbegin",
        `<div class="alert alert-error" style="margin-bottom:24px">The app could not load its model list: ${esc(err.message)}</div>`);
      return;
    }
    setupEvaluator();
    setupClassification();
    setupRegression();
    await refreshTrained();
  }

  init();
})();

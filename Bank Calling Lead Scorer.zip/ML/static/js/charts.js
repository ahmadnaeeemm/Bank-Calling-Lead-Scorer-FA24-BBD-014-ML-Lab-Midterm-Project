/* Small dependency-free SVG/HTML charts. Every value plotted comes from an API response. */
(function () {
  "use strict";

  // Small viewBox so labels stay legible when a chart is scaled into a half-width column.
  const W = 400;
  const H = 280;
  const M = { top: 14, right: 14, bottom: 46, left: 54 };
  const SERIES = ["#2563eb", "#d97706", "#059669", "#7c3aed", "#db2777", "#0891b2", "#65a30d", "#475569"];

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function niceStep(span, count) {
    const raw = span / Math.max(count, 1);
    const power = Math.pow(10, Math.floor(Math.log10(raw)));
    const fraction = raw / power;
    const nice = fraction < 1.5 ? 1 : fraction < 3 ? 2 : fraction < 7 ? 5 : 10;
    return nice * power;
  }

  function ticks(min, max, count) {
    if (min === max) { min -= 1; max += 1; }
    const step = niceStep(max - min, count);
    const start = Math.ceil(min / step) * step;
    const out = [];
    for (let v = start; v <= max + step * 1e-9; v += step) out.push(Math.abs(v) < step * 1e-9 ? 0 : v);
    return out;
  }

  function extent(values, padFraction) {
    let min = Infinity;
    let max = -Infinity;
    values.forEach((v) => { if (Number.isFinite(v)) { min = Math.min(min, v); max = Math.max(max, v); } });
    if (!Number.isFinite(min)) return [0, 1];
    if (min === max) return [min - 1, max + 1];
    const pad = (max - min) * (padFraction || 0);
    return [min - pad, max + pad];
  }

  function formatTick(v) {
    const a = Math.abs(v);
    if (a >= 10000) return (v / 1000).toLocaleString(undefined, { maximumFractionDigits: 0 }) + "k";
    if (a >= 100) return v.toLocaleString(undefined, { maximumFractionDigits: 0 });
    return Number(v.toPrecision(3)).toString();
  }

  function frame(xDomain, yDomain, xLabel, yLabel) {
    const iw = W - M.left - M.right;
    const ih = H - M.top - M.bottom;
    const sx = (v) => M.left + ((v - xDomain[0]) / (xDomain[1] - xDomain[0])) * iw;
    const sy = (v) => M.top + ih - ((v - yDomain[0]) / (yDomain[1] - yDomain[0])) * ih;
    const xt = ticks(xDomain[0], xDomain[1], 6).filter((t) => t >= xDomain[0] && t <= xDomain[1]);
    const yt = ticks(yDomain[0], yDomain[1], 5).filter((t) => t >= yDomain[0] && t <= yDomain[1]);
    let svg = '<g class="grid">';
    yt.forEach((t) => { svg += `<line x1="${M.left}" x2="${W - M.right}" y1="${sy(t)}" y2="${sy(t)}"/>`; });
    svg += '</g><g class="axis">';
    svg += `<line x1="${M.left}" x2="${W - M.right}" y1="${M.top + ih}" y2="${M.top + ih}"/>`;
    svg += `<line x1="${M.left}" x2="${M.left}" y1="${M.top}" y2="${M.top + ih}"/>`;
    xt.forEach((t) => { svg += `<text x="${sx(t)}" y="${M.top + ih + 18}" text-anchor="middle">${formatTick(t)}</text>`; });
    yt.forEach((t) => { svg += `<text x="${M.left - 8}" y="${sy(t) + 4}" text-anchor="end">${formatTick(t)}</text>`; });
    svg += "</g>";
    svg += `<text class="axis-title" x="${M.left + iw / 2}" y="${H - 10}" text-anchor="middle">${escapeHtml(xLabel)}</text>`;
    svg += `<text class="axis-title" transform="translate(16 ${M.top + ih / 2}) rotate(-90)" text-anchor="middle">${escapeHtml(yLabel)}</text>`;
    return { svg, sx, sy, iw, ih };
  }

  function wrap(svgBody, title) {
    return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${escapeHtml(title)}">${svgBody}</svg>`;
  }

  function path(xs, ys, sx, sy) {
    return xs.map((x, i) => `${i ? "L" : "M"}${sx(x).toFixed(1)},${sy(ys[i]).toFixed(1)}`).join("");
  }

  /** series: [{label, x: [], y: []}]; options: xLabel, yLabel, xDomain, yDomain, diagonal, marker {x, label} */
  function lineChart(series, options) {
    const xs = series.flatMap((s) => s.x);
    const ys = series.flatMap((s) => s.y);
    const xDomain = options.xDomain || extent(xs, 0);
    const yDomain = options.yDomain || extent(ys, 0.05);
    const f = frame(xDomain, yDomain, options.xLabel, options.yLabel);
    let body = f.svg;
    if (options.diagonal) {
      body += `<line x1="${f.sx(xDomain[0])}" y1="${f.sy(yDomain[0])}" x2="${f.sx(xDomain[1])}" y2="${f.sy(yDomain[1])}" stroke="#94a3b8" stroke-dasharray="4 4"/>`;
    }
    if (options.marker) {
      const mx = f.sx(options.marker.x);
      body += `<line x1="${mx}" x2="${mx}" y1="${M.top}" y2="${M.top + f.ih}" stroke="#0f172a" stroke-dasharray="3 3"/>`;
      body += `<text x="${mx + 6}" y="${M.top + 12}" class="axis-title">${escapeHtml(options.marker.label)}</text>`;
    }
    series.forEach((s, i) => {
      body += `<path d="${path(s.x, s.y, f.sx, f.sy)}" fill="none" stroke="${s.color || SERIES[i % SERIES.length]}" stroke-width="2" stroke-linejoin="round"/>`;
    });
    let legend = "";
    if (series.length > 1) {
      legend = '<ul class="legend">' + series.map((s, i) =>
        `<li><span class="swatch" style="background:${s.color || SERIES[i % SERIES.length]}"></span>${escapeHtml(s.label)}</li>`).join("") + "</ul>";
    }
    return wrap(body, options.title || options.yLabel) + legend;
  }

  /** Scatter of points with an optional fitted line and y = x reference. */
  function scatterChart(x, y, options) {
    const lineX = options.line ? options.line.x : [];
    const lineY = options.line ? options.line.y : [];
    let xDomain = extent(x.concat(lineX), 0.04);
    let yDomain = extent(y.concat(lineY), 0.04);
    if (options.diagonal) {
      const both = extent(x.concat(y), 0.04);
      xDomain = both;
      yDomain = both;
    }
    const f = frame(xDomain, yDomain, options.xLabel, options.yLabel);
    let body = f.svg;
    if (options.zeroLine && yDomain[0] < 0 && yDomain[1] > 0) {
      body += `<line x1="${M.left}" x2="${W - M.right}" y1="${f.sy(0)}" y2="${f.sy(0)}" stroke="#0f172a" stroke-dasharray="4 4"/>`;
    }
    if (options.diagonal) {
      body += `<line x1="${f.sx(xDomain[0])}" y1="${f.sy(xDomain[0])}" x2="${f.sx(xDomain[1])}" y2="${f.sy(xDomain[1])}" stroke="#0f172a" stroke-dasharray="4 4"/>`;
    }
    body += '<g fill="#2563eb" fill-opacity="0.35">';
    x.forEach((v, i) => { body += `<circle cx="${f.sx(v).toFixed(1)}" cy="${f.sy(y[i]).toFixed(1)}" r="2.6"/>`; });
    body += "</g>";
    if (options.line) {
      body += `<path d="${path(lineX, lineY, f.sx, f.sy)}" fill="none" stroke="#d97706" stroke-width="2.5"/>`;
    }
    return wrap(body, options.title || options.yLabel);
  }

  /** Horizontal HTML bars. items: [{label, value}]; signed centres the axis for +/- values. */
  function bars(items, options) {
    if (!items.length) return '<p class="meta">Nothing to show.</p>';
    const fmt = options.format || ((v) => v.toFixed(3));
    const maxAbs = Math.max(...items.map((d) => Math.abs(d.value))) || 1;
    const max = options.max || maxAbs;
    const rows = items.map((d) => {
      let style;
      if (options.signed) {
        const width = (Math.abs(d.value) / maxAbs) * 50;
        style = d.value >= 0 ? `left:50%;width:${width}%` : `left:${50 - width}%;width:${width}%`;
      } else {
        style = `left:0;width:${Math.max(0, (d.value / max) * 100)}%`;
      }
      return `<div class="bar-row"><span class="bar-label" title="${escapeHtml(d.label)}">${escapeHtml(d.label)}</span>` +
        `<span class="bar-track${options.signed ? " signed" : ""}"><span class="bar-fill${d.value < 0 ? " negative" : ""}" style="${style}"></span></span>` +
        `<span class="bar-value">${fmt(d.value)}</span></div>`;
    });
    return `<div class="bars">${rows.join("")}</div>`;
  }

  /** Confusion matrix with rows = actual and columns = predicted. */
  function confusion(matrix, labels) {
    const total = matrix.flat().reduce((a, b) => a + b, 0) || 1;
    const max = Math.max(...matrix.flat()) || 1;
    let html = '<table class="confusion"><thead><tr><th></th><th></th>';
    html += `<th colspan="${labels.length}" class="axis-label">Predicted</th></tr><tr><th></th><th></th>`;
    labels.forEach((l) => { html += `<th>${escapeHtml(l)}</th>`; });
    html += "</tr></thead><tbody>";
    matrix.forEach((row, i) => {
      html += "<tr>";
      if (i === 0) html += `<th rowspan="${labels.length}" class="axis-label" style="writing-mode:vertical-rl;transform:rotate(180deg)">Actual</th>`;
      html += `<th>${escapeHtml(labels[i])}</th>`;
      row.forEach((count, j) => {
        const alpha = 0.08 + 0.55 * (count / max);
        const tint = i === j ? `rgba(37,99,235,${alpha})` : `rgba(217,119,6,${alpha * 0.8})`;
        html += `<td class="cell" style="background:${tint}">${count.toLocaleString()}<small>${((count / total) * 100).toFixed(1)}%</small></td>`;
      });
      html += "</tr>";
    });
    return html + "</tbody></table>";
  }

  window.Charts = { lineChart, scatterChart, bars, confusion, escapeHtml, SERIES };
})();

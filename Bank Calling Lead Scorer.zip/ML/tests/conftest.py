import pytest

from src.components.model_trainer import ExperimentService


@pytest.fixture(scope="session")
def service() -> ExperimentService:
    """One service per test run: the dataset is read once and models are shared across tests."""
    return ExperimentService()

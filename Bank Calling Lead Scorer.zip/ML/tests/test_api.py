import pytest
from fastapi.testclient import TestClient

from app import create_app


@pytest.fixture(scope="module")
def client(service):
    return TestClient(create_app(service))


def test_index_serves_the_gui(client) -> None:
    response = client.get("/")
    assert response.status_code == 200
    html = response.text
    for marker in ("Outbound Sales Propensity Evaluator", 'id="tab-classification"', 'id="tab-regression"', "js/app.js"):
        assert marker in html


def test_static_assets_are_served(client) -> None:
    for path in ("/static/css/app.css", "/static/js/app.js", "/static/js/charts.js"):
        assert client.get(path).status_code == 200


def test_health_and_warm_start(client) -> None:
    body = client.get("/api/health").json()
    assert body["status"] == "ok" and body["rows"] == 11162
    trained = client.get("/api/models/trained").json()["models"]
    assert any(m["model"] == "logistic_regression" and m["task"] == "classification" for m in trained)


def test_dataset_endpoints(client) -> None:
    summary = client.get("/api/dataset").json()
    assert summary["rows"] == 11162 and summary["dropped"] == ["duration"]
    preview = client.get("/api/dataset/preview?offset=0&limit=3").json()
    assert len(preview["rows"]) == 3 and "duration" in preview["columns"]
    assert client.get("/api/dataset/preview?limit=abc").status_code == 400
    assert client.get("/api/dataset/preview?limit=1000").status_code == 400
    rates = client.get("/api/dataset/rates?column=poutcome").json()["rates"]
    assert rates[0]["group"] == "Subscribed"  # previous success has the highest rate
    assert client.get("/api/dataset/rates?column=nope").status_code == 400


def test_catalog_lists_every_model_and_no_leaky_input(client) -> None:
    catalog = client.get("/api/models").json()
    assert [m["key"] for m in catalog["classification"]["models"]] == [
        "logistic_regression", "decision_tree", "random_forest"]
    assert [m["key"] for m in catalog["regression"]["models"]] == ["simple_linear", "multiple_linear"]
    assert "duration" not in catalog["classification"]["features"]
    assert "deposit" not in [t["name"] for t in catalog["regression"]["targets"]]


def test_classification_train_and_predict_workflow(client) -> None:
    response = client.post("/api/classification/train",
                           json={"model": "random_forest", "params": {"n_estimators": 50}})
    assert response.status_code == 200
    result = response.json()
    assert result["params"]["n_estimators"] == 50 and result["split"]["test"] == 2233
    values = {f["name"]: f["default"] for f in result["schema"]}
    prediction = client.post("/api/predict", json={"task": "classification", "model": "random_forest",
                                                   "values": values})
    assert prediction.status_code == 200
    body = prediction.json()
    assert body["predicted"] in ("yes", "no") and 0 <= body["score"] <= 1


def test_classification_compare(client) -> None:
    body = client.post("/api/classification/compare", json={"test_size": 0.25, "random_state": 3}).json()
    assert len(body["rows"]) == 3 and body["split"]["test"] == 2791
    assert all(0.5 < row["accuracy"] < 1 for row in body["rows"])


def test_regression_train_and_compare(client) -> None:
    result = client.post("/api/regression/train", json={
        "model": "multiple_linear", "target": "balance", "features": ["age", "job"]}).json()
    assert result["metrics"]["test"]["r2"] is not None and result["details"]["coefficients"]
    body = client.post("/api/regression/compare", json={"target": "age", "features": ["job", "marital"]}).json()
    assert {s["model"] for s in body["skipped"]} == {"simple_linear"}  # no numeric input


@pytest.mark.parametrize("path, payload, field", [
    ("/api/classification/train", {"model": "boosting"}, "model"),
    ("/api/classification/train", {"model": "logistic_regression", "params": {"C": 0}}, "C"),
    ("/api/classification/train", {"model": "random_forest", "test_size": 0.99}, "test_size"),
    ("/api/classification/train", {"model": "random_forest", "features": ["duration"]}, "features"),
    ("/api/regression/train", {"model": "simple_linear", "target": "deposit"}, "target"),
    ("/api/classification/train", {"model": "svm"}, "model"),
    ("/api/classification/train", {"model": "gaussian_nb"}, "model"),
    ("/api/regression/train", {"model": "polynomial", "target": "age"}, "model"),
    ("/api/predict", {"task": "classification", "model": "mlp"}, "model"),
    ("/api/predict", {"task": "clustering", "model": "random_forest"}, "task"),
])
def test_invalid_requests_return_400_with_field(client, path, payload, field) -> None:
    response = client.post(path, json=payload)
    assert response.status_code == 400
    assert response.json()["field"] == field


def test_unseen_category_is_rejected_at_prediction(client) -> None:
    trained = client.get("/api/models/trained").json()["models"]
    model = next(m for m in trained if m["model"] == "logistic_regression")
    values = {f["name"]: f["default"] for f in model["schema"]}
    response = client.post("/api/predict", json={"task": "classification", "model": "logistic_regression",
                                                 "values": {**values, "month": "smarch"}})
    assert response.status_code == 400 and response.json()["field"] == "month"


def test_non_json_body_is_rejected(client) -> None:
    response = client.post("/api/classification/train", content="model=random_forest",
                           headers={"Content-Type": "text/plain"})
    assert response.status_code == 400 and "JSON" in response.json()["error"]


def test_unknown_route_returns_json_404(client) -> None:
    response = client.get("/api/nothing")
    assert response.status_code == 404 and "error" in response.json()


def test_unexpected_errors_return_json_500(service, monkeypatch) -> None:
    # raise_server_exceptions=False lets the 500 handler answer instead of re-raising in the test.
    client = TestClient(create_app(service, warm_start=False), raise_server_exceptions=False)
    monkeypatch.setattr(service, "train_classifier", lambda body: 1 / 0)
    response = client.post("/api/classification/train", json={"model": "random_forest"})
    assert response.status_code == 500 and "ZeroDivisionError" in response.json()["error"]

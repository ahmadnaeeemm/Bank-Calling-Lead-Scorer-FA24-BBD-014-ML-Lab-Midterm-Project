import pytest
from sklearn import metrics as sk
from sklearn.ensemble import RandomForestClassifier

from src.components import classifiers as clf
from src.components.data_ingestion import FEATURES
from src.components.model_params import validate_params
from src.components.data_transform import make_split
from src.exception import ValidationError


@pytest.mark.parametrize("key", list(clf.SPECS))
def test_every_classifier_trains_and_metrics_match_scikit_learn(service, key) -> None:
    result = service.train_classifier({"model": key, "test_size": 0.2, "random_state": 7})
    split = make_split(service.X, service.y, 0.2, 7, stratify=True)
    pipeline = service._models[("classification", key)].pipeline
    y_pred = pipeline.predict(split.X_test)
    assert y_pred.shape == (len(split.y_test),)
    m = result["metrics"]
    assert m["accuracy"] == pytest.approx(sk.accuracy_score(split.y_test, y_pred))
    assert m["precision"] == pytest.approx(sk.precision_score(split.y_test, y_pred, zero_division=0))
    assert m["recall"] == pytest.approx(sk.recall_score(split.y_test, y_pred))
    assert m["f1"] == pytest.approx(sk.f1_score(split.y_test, y_pred))
    scores = clf.probability_of_yes(pipeline, split.X_test)
    assert m["roc_auc"] == pytest.approx(sk.roc_auc_score(split.y_test, scores))
    assert ((scores >= 0) & (scores <= 1)).all()  # every classifier gives a real probability
    cm = sk.confusion_matrix(split.y_test, y_pred, labels=[0, 1])
    assert result["report"]["confusion_matrix"] == cm.tolist()
    assert m["accuracy"] > m["baseline_accuracy"]  # better than always predicting the majority class


def test_logistic_regression_lists_top_weights(service) -> None:
    details = service.train_classifier({"model": "logistic_regression"})["details"]
    assert len(details["weights"]) == 10
    assert not details["weights"][0]["term"].startswith(("num__", "cat__"))  # names are cleaned up


def test_catalog_has_exactly_the_three_classifiers() -> None:
    assert list(clf.SPECS) == ["logistic_regression", "decision_tree", "random_forest"]


def test_random_forest_defaults_and_details(service) -> None:
    result = service.train_classifier({"model": "random_forest"})
    model = service._models[("classification", "random_forest")].pipeline.named_steps["model"]
    assert isinstance(model, RandomForestClassifier)
    assert model.n_estimators == 100 and model.random_state == 42
    assert result["details"]["trees"] == 100
    assert result["details"]["importances"]
    assert result["metrics"]["accuracy"] > result["metrics"]["baseline_accuracy"]


def test_random_forest_settings_are_used(service) -> None:
    service.train_classifier({"model": "random_forest", "params": {"n_estimators": 20, "max_depth": 4}})
    model = service._models[("classification", "random_forest")].pipeline.named_steps["model"]
    assert model.n_estimators == 20 and max(t.get_depth() for t in model.estimators_) <= 4


def test_tree_depth_respects_max_depth(service) -> None:
    result = service.train_classifier({"model": "decision_tree", "params": {"max_depth": 3, "criterion": "entropy"}})
    assert result["details"]["depth"] <= 3
    assert "|---" in result["details"]["rules"]
    unpruned = service.train_classifier({"model": "decision_tree", "params": {"max_depth": ""}})
    assert unpruned["details"]["depth"] > 3
    assert unpruned["metrics"]["train_accuracy"] > unpruned["metrics"]["accuracy"]  # an unpruned tree overfits


def test_feature_subset_controls_schema(service) -> None:
    result = service.train_classifier({"model": "decision_tree", "features": ["age", "poutcome", "housing"]})
    assert {f["name"] for f in result["schema"]} == {"age", "poutcome", "housing"}


@pytest.mark.parametrize("key, params, field", [
    ("logistic_regression", {"C": -1}, "C"), ("logistic_regression", {"C": "abc"}, "C"),
    ("decision_tree", {"criterion": "random"}, "criterion"), ("decision_tree", {"max_depth": 0}, "max_depth"),
    ("random_forest", {"kernel": "rbf"}, "kernel"),
])
def test_parameter_validation(key, params, field) -> None:
    with pytest.raises(ValidationError) as err:
        validate_params(clf.SPECS[key], params)
    assert err.value.field == field


@pytest.mark.parametrize("value", ["0", "5000", "abc", "2.5"])
def test_random_forest_tree_count_validation(value) -> None:
    with pytest.raises(ValidationError):
        validate_params(clf.SPECS["random_forest"], {"n_estimators": value})


@pytest.mark.parametrize("key", ["knn", "mlp", "neuron_gd", "multinomial_nb", "gaussian_nb", "svm"])
def test_removed_classifiers_are_rejected(service, key) -> None:
    with pytest.raises(ValidationError):
        service.train_classifier({"model": key})


def test_unknown_model_and_target_as_feature_are_rejected(service) -> None:
    with pytest.raises(ValidationError):
        service.train_classifier({"model": "gradient_boosting"})
    with pytest.raises(ValidationError):
        service.train_classifier({"model": "random_forest", "features": ["age", "deposit"]})


def test_prediction_says_yes_at_fifty_percent_or_more(service) -> None:
    service.train_classifier({"model": "random_forest"})
    schema = service._models[("classification", "random_forest")].schema
    result = service.predict({"task": "classification", "model": "random_forest",
                              "values": {f["name"]: f["default"] for f in schema}})
    assert result["threshold"] == 0.5 and 0 <= result["score"] <= 1
    assert result["predicted"] == ("yes" if result["score"] >= 0.5 else "no")


def test_prediction_uses_fitted_preprocessing(service) -> None:
    service.train_classifier({"model": "logistic_regression"})
    trained = service._models[("classification", "logistic_regression")]
    values = {f["name"]: f["default"] for f in trained.schema}
    result = service.predict({"task": "classification", "model": "logistic_regression", "values": values})
    split = make_split(service.X, service.y, 0.2, 42, stratify=True)
    row = split.X_train.iloc[[0]].copy()
    for name, value in values.items():
        row[name] = value
    assert result["score"] == pytest.approx(trained.pipeline.predict_proba(row[FEATURES])[0, 1])

import hashlib
from pathlib import Path

import pandas as pd
import pytest

from src.components.data_ingestion import (DATA_PATH, EXPECTED_COLUMNS, FEATURES, LEAKY_COLUMNS, TARGET, DatasetError, describe_dataset,
                  load_dataset, preview_rows, read_raw_dataset, split_features_target, subscription_rate_by)

VALID_ROW = {"age": 30, "job": "admin.", "marital": "single", "education": "secondary", "default": "no",
             "balance": 100, "housing": "yes", "loan": "no", "contact": "cellular", "day": 5, "month": "may",
             "duration": 120, "campaign": 1, "pdays": -1, "previous": 0, "poutcome": "unknown", "deposit": "yes"}


def write_csv(tmp_path: Path, rows: list[dict], columns: list[str] = EXPECTED_COLUMNS) -> Path:
    path = tmp_path / "bank.csv"
    pd.DataFrame(rows, columns=columns).to_csv(path, index=False)
    return path


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_real_dataset_shape_and_columns() -> None:
    raw = read_raw_dataset()
    assert raw.shape == (11162, 17)
    assert list(raw.columns) == EXPECTED_COLUMNS
    df = load_dataset()
    assert "duration" not in df.columns
    assert df.shape == (11162, 16)


def test_features_exclude_target_and_leaky_columns() -> None:
    X, y = split_features_target(load_dataset())
    assert list(X.columns) == FEATURES
    assert TARGET not in X.columns
    assert not set(LEAKY_COLUMNS) & set(X.columns)
    assert set(y.unique()) == {0, 1}
    assert int(y.sum()) == 5289  # "yes" encoded as 1


def test_summary_matches_assignment_quality_checks() -> None:
    summary = describe_dataset(read_raw_dataset())
    assert summary["missing_cells"] == 0
    assert summary["duplicate_rows"] == 0
    assert summary["target_counts"] == {"no": 5873, "yes": 5289}
    assert summary["pdays_never_contacted"] == 8324
    roles = {c["name"]: c["role"] for c in summary["columns_info"]}
    assert roles["duration"] == "dropped" and roles["deposit"] == "target"


def test_original_file_is_never_modified(service) -> None:
    before = sha256(DATA_PATH)
    service.train_classifier({"model": "decision_tree"})
    service.train_regressor({"model": "multiple_linear", "target": "age", "features": ["job", "balance"]})
    assert sha256(DATA_PATH) == before


def test_target_is_encoded(tmp_path: Path) -> None:
    rows = [VALID_ROW, {**VALID_ROW, "deposit": "no"}]
    X, y = split_features_target(load_dataset(write_csv(tmp_path, rows)))
    assert list(X.columns) == FEATURES
    assert y.tolist() == [1, 0]


def test_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError):
        load_dataset(tmp_path / "nope.csv")


def test_empty_file_raises(tmp_path: Path) -> None:
    path = tmp_path / "bank.csv"
    path.write_text("")
    with pytest.raises(DatasetError, match="empty"):
        load_dataset(path)


def test_header_only_file_raises(tmp_path: Path) -> None:
    with pytest.raises(DatasetError, match="no rows"):
        load_dataset(write_csv(tmp_path, []))


def test_missing_duration_column_raises(tmp_path: Path) -> None:
    columns = [c for c in EXPECTED_COLUMNS if c != "duration"]
    with pytest.raises(DatasetError, match="duration"):
        load_dataset(write_csv(tmp_path, [VALID_ROW], columns))


def test_non_numeric_value_raises(tmp_path: Path) -> None:
    with pytest.raises(DatasetError, match="age"):
        load_dataset(write_csv(tmp_path, [{**VALID_ROW, "age": "thirty"}]))


def test_empty_cell_raises(tmp_path: Path) -> None:
    with pytest.raises(DatasetError, match="empty cells"):
        load_dataset(write_csv(tmp_path, [{**VALID_ROW, "job": None}]))


def test_unexpected_target_value_raises(tmp_path: Path) -> None:
    with pytest.raises(DatasetError, match="maybe"):
        load_dataset(write_csv(tmp_path, [{**VALID_ROW, "deposit": "maybe"}]))


def test_numeric_rate_bins_are_in_value_order() -> None:
    rates = subscription_rate_by(read_raw_dataset(), "balance")
    lower_bounds = [float(r["group"].split(" to ")[0].replace(",", "")) for r in rates]
    assert lower_bounds == sorted(lower_bounds)
    assert sum(r["count"] for r in rates) == 11162


def test_rates_reject_unknown_column() -> None:
    with pytest.raises(DatasetError):
        subscription_rate_by(read_raw_dataset(), "duration")


def test_preview_limits() -> None:
    raw = read_raw_dataset()
    page = preview_rows(raw, 10, 5)
    assert len(page["rows"]) == 5 and page["total"] == 11162
    with pytest.raises(DatasetError):
        preview_rows(raw, 0, 500)

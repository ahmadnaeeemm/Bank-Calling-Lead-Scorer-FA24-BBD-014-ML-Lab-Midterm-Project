import numpy as np
import pytest
from sklearn import metrics as sk

from src.components.evaluation import classification_report, confusion_matrix, regression_metrics, roc_curve

rng = np.random.default_rng(0)


def test_regression_metrics_values() -> None:
    y_true = rng.normal(50, 10, 300)
    y_pred = y_true + rng.normal(0, 4, 300)
    m = regression_metrics(y_true, y_pred)
    assert m["mae"] == pytest.approx(sk.mean_absolute_error(y_true, y_pred))
    assert m["mse"] == pytest.approx(sk.mean_squared_error(y_true, y_pred))
    assert m["rmse"] == pytest.approx(np.sqrt(m["mse"]))
    assert m["r2"] == pytest.approx(sk.r2_score(y_true, y_pred))


def test_r2_is_undefined_for_constant_target() -> None:
    assert regression_metrics([5.0, 5.0, 5.0], [4.0, 5.0, 6.0])["r2"] is None


def test_confusion_matrix_rows_are_actual_class() -> None:
    ours = confusion_matrix([0, 0, 0, 1, 1], [0, 1, 1, 1, 0], labels=[0, 1])
    assert ours[0, 1] == 2  # two actual "no" predicted as "yes"


def test_classification_report_values() -> None:
    y_true = rng.integers(0, 2, 500)
    y_pred = np.where(rng.random(500) < 0.7, y_true, 1 - y_true)
    report = classification_report(y_true, y_pred, labels=[0, 1], names=["no", "yes"])
    p, r, f, s = sk.precision_recall_fscore_support(y_true, y_pred, labels=[0, 1])
    for i, row in enumerate(report["per_class"]):
        assert row["precision"] == pytest.approx(p[i])
        assert row["recall"] == pytest.approx(r[i])
        assert row["f1"] == pytest.approx(f[i])
        assert row["support"] == s[i]
    assert report["accuracy"] == pytest.approx(sk.accuracy_score(y_true, y_pred))


def test_missing_predicted_class_reports_zero_not_nan() -> None:
    yes = classification_report([0, 1, 1], [0, 0, 0], labels=[0, 1], names=["no", "yes"])["per_class"][1]
    assert yes["precision"] == 0.0 and yes["recall"] == 0.0 and yes["f1"] == 0.0


def test_roc_curve_and_auc() -> None:
    y_true = rng.integers(0, 2, 400)
    scores = y_true * 0.3 + rng.random(400)
    roc = roc_curve(y_true, scores)
    assert roc["auc"] == pytest.approx(sk.roc_auc_score(y_true, scores))
    assert roc["fpr"][0] == 0 and roc["tpr"][-1] == 1


def test_roc_with_one_class_has_no_auc() -> None:
    roc = roc_curve(np.array([1, 1, 1]), np.array([0.2, 0.5, 0.9]))
    assert roc["auc"] is None and roc["reason"]


def test_bad_input_raises() -> None:
    with pytest.raises(ValueError):
        regression_metrics([1.0, 2.0], [1.0])
    with pytest.raises(ValueError):
        classification_report([], [], labels=[0, 1], names=["no", "yes"])

import copy

import pandas as pd
import pytest
from fastapi.testclient import TestClient

from app import create_app
from src.components.model_trainer import ExperimentService
from src.exception import ModelNotFoundError, ValidationError
from src.pipelines import predict_pipeline, train_pipeline
from src.utils import load_config


@pytest.fixture(scope="module")
def trained(tmp_path_factory):
    """Run the full train pipeline into a temporary project layout."""
    root = tmp_path_factory.mktemp("artifacts")
    config = copy.deepcopy(load_config())
    config["data"]["interim_path"] = str(root / "interim" / "clean.csv")
    config["data"]["processed_dir"] = str(root / "processed")
    config["artifacts"]["models_dir"] = str(root / "models")
    config["artifacts"]["reports_dir"] = str(root / "reports")
    return root, train_pipeline.run(config)


def test_train_pipeline_writes_every_artifact(trained) -> None:
    root, summary = trained
    assert len(summary["model_paths"]) == 5  # 3 classifiers + 2 regression models
    assert {p.name for p in (root / "reports").iterdir()} == {
        "classification_comparison.csv", "regression_comparison.csv", "metrics.json"}
    train = pd.read_csv(root / "processed" / "train.csv")
    test = pd.read_csv(root / "processed" / "test.csv")
    assert len(train) + len(test) == 11162 and len(test) == 2233
    assert "duration" not in train.columns and set(train["deposit"]) == {"yes", "no"}
    assert not set(train["source_row"]) & set(test["source_row"])
    assert "duration" not in pd.read_csv(root / "interim" / "clean.csv").columns


def test_saved_model_matches_in_memory_model(trained) -> None:
    root, _ = trained
    pipeline = predict_pipeline.PredictPipeline(root / "models")
    test = pd.read_csv(root / "processed" / "test.csv")
    scored = pipeline.predict_frame("classification", "logistic_regression", test)
    accuracy = (scored["predicted"] == scored["deposit"]).mean()
    reported = pd.read_csv(root / "reports" / "classification_comparison.csv")
    assert accuracy == pytest.approx(reported.loc[reported["label"] == "Logistic Regression", "accuracy"].item())


def test_predict_pipeline_errors(trained) -> None:
    root, _ = trained
    pipeline = predict_pipeline.PredictPipeline(root / "models")
    with pytest.raises(ModelNotFoundError):
        pipeline.load("classification", "knn")  # removed model, so there is no saved file
    with pytest.raises(ValidationError):
        pipeline.predict_frame("classification", "random_forest", pd.DataFrame({"age": [30]}))
    with pytest.raises(ValidationError):
        pipeline.load("clustering", "random_forest")


def test_app_loads_saved_models(trained) -> None:
    root, _ = trained
    service = ExperimentService()
    app = create_app(service, warm_start=False, models_dir=root / "models")
    models = TestClient(app).get("/api/models/trained").json()["models"]
    assert len(models) == 5


def test_cli_reports_bad_input_without_traceback(trained, monkeypatch) -> None:
    root, _ = trained
    original = predict_pipeline.PredictPipeline
    monkeypatch.setattr(predict_pipeline, "PredictPipeline", lambda: original(root / "models"))
    with pytest.raises(SystemExit, match="Error: Missing values"):
        predict_pipeline.main(["--model", "random_forest", "--values", '{"job": "admin."}'])

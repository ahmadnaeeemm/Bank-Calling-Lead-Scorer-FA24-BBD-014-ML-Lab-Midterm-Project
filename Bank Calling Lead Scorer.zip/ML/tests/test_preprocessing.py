import numpy as np
import pytest

from src.components import classifiers as clf
from src.components.data_ingestion import FEATURES
from src.components.data_transform import (ValidationError, input_schema, make_split, validate_features, validate_sample,
                           validate_split_settings)


@pytest.fixture(scope="module")
def split(service):
    return make_split(service.X, service.y, 0.2, 42, stratify=True)


@pytest.fixture(scope="module")
def schema(split):
    return input_schema(FEATURES, split.X_train)


def valid_values(schema: list[dict]) -> dict:
    return {f["name"]: f["default"] for f in schema}


def test_split_is_stratified_and_reproducible(service, split) -> None:
    again = make_split(service.X, service.y, 0.2, 42, stratify=True)
    assert split.X_test.index.equals(again.X_test.index)
    assert abs(split.y_train.mean() - split.y_test.mean()) < 0.005
    assert not set(split.X_train.index) & set(split.X_test.index)


def test_scaler_is_fitted_on_training_rows_only(split) -> None:
    pipeline = clf.build_pipeline("logistic_regression", {"C": 1.0, "max_iter": 1000}, FEATURES, 42)
    pipeline.fit(split.X_train, split.y_train)
    scaler = pipeline.named_steps["preprocess"].named_transformers_["num"]
    train_mean = split.X_train[["age", "balance", "day", "campaign", "pdays", "previous"]].mean().to_numpy()
    assert np.allclose(scaler.mean_, train_mean)
    full_mean = split.X_test["balance"].mean()
    assert not np.isclose(scaler.mean_[1], full_mean)


def test_schema_options_come_from_training_data(split, schema) -> None:
    job = next(f for f in schema if f["name"] == "job")
    assert [o["value"] for o in job["options"]] == sorted(split.X_train["job"].unique())
    age = next(f for f in schema if f["name"] == "age")
    assert age["min"] == split.X_train["age"].min()


def test_valid_sample_round_trips(schema) -> None:
    frame, warnings = validate_sample(valid_values(schema), schema)
    assert frame.shape == (1, len(FEATURES)) and warnings == []


def test_unseen_category_is_rejected(schema) -> None:
    with pytest.raises(ValidationError) as err:
        validate_sample({**valid_values(schema), "job": "astronaut"}, schema)
    assert err.value.field == "job"


@pytest.mark.parametrize("value", ["abc", None, True, float("nan"), 30.5])
def test_bad_numbers_are_rejected(schema, value) -> None:
    with pytest.raises(ValidationError) as err:
        validate_sample({**valid_values(schema), "age": value}, schema)
    assert err.value.field == "age"


def test_missing_and_extra_fields_are_rejected(schema) -> None:
    values = valid_values(schema)
    with pytest.raises(ValidationError, match="Missing"):
        validate_sample({k: v for k, v in values.items() if k != "balance"}, schema)
    with pytest.raises(ValidationError, match="does not use"):
        validate_sample({**values, "duration": 300}, schema)


def test_out_of_range_number_warns_but_predicts(schema) -> None:
    frame, warnings = validate_sample({**valid_values(schema), "age": 120}, schema)
    assert frame.loc[0, "age"] == 120 and "outside the training range" in warnings[0]


@pytest.mark.parametrize("test_size, seed", [(0.05, 1), (0.9, 1), ("x", 1), (0.2, -1), (0.2, 1.5), (0.2, True)])
def test_bad_split_settings(test_size, seed) -> None:
    with pytest.raises(ValidationError):
        validate_split_settings(test_size, seed)


def test_feature_validation() -> None:
    assert validate_features(["balance", "age"], FEATURES) == ["age", "balance"]
    for bad in (["duration"], ["deposit"], [], "age"):
        with pytest.raises(ValidationError):
            validate_features(bad, FEATURES)

import numpy as np
import pandas as pd
import pytest
from sklearn import metrics as sk

from src.components import regressors as reg
from src.components.data_transform import make_split
from src.exception import ValidationError


def test_simple_linear_matches_closed_form_least_squares(service) -> None:
    result = service.train_regressor({"model": "simple_linear", "target": "age", "features": ["balance"]})
    split = make_split(service.X[["balance"]], service.X["age"], 0.2, 42, stratify=False)
    slope, intercept = np.polyfit(split.X_train["balance"], split.y_train, 1)
    coefs = {c["term"]: c["coefficient"] for c in result["details"]["coefficients"]}
    assert coefs["balance"] == pytest.approx(slope)
    assert result["details"]["intercept"] == pytest.approx(intercept)


def test_multiple_linear_metrics(service) -> None:
    features = ["job", "marital", "education", "balance", "housing", "loan"]
    result = service.train_regressor({"model": "multiple_linear", "target": "age", "features": features})
    split = make_split(service.X[features], service.X["age"], 0.2, 42, stratify=False)
    pipeline = service._models[("regression", "multiple_linear")].pipeline
    y_pred = pipeline.predict(split.X_test)
    assert result["metrics"]["test"]["r2"] == pytest.approx(sk.r2_score(split.y_test, y_pred))
    assert result["metrics"]["test"]["mae"] == pytest.approx(sk.mean_absolute_error(split.y_test, y_pred))
    # One coefficient per encoded input; the first level of each category is the reference (dropped).
    assert "job_admin." not in {c["term"] for c in result["details"]["coefficients"]}


def test_simple_linear_recovers_a_straight_line() -> None:
    age = np.linspace(18, 90, 200)
    X = pd.DataFrame({"age": age})
    y = pd.Series(3 + 0.2 * age)
    pipeline = reg.build_pipeline("simple_linear", {}, ["age"]).fit(X, y)
    assert sk.r2_score(y, pipeline.predict(X)) == pytest.approx(1.0)


def test_catalog_has_exactly_the_two_regression_models() -> None:
    assert list(reg.SPECS) == ["simple_linear", "multiple_linear"]


@pytest.mark.parametrize("key", ["polynomial", "knn_regression"])
def test_removed_regression_models_are_rejected(service, key) -> None:
    with pytest.raises(ValidationError):
        service.train_regressor({"model": key, "target": "age", "features": ["balance", "job"]})


@pytest.mark.parametrize("key, features", [
    ("simple_linear", ["balance", "day"]), ("simple_linear", ["job"]),
    ("multiple_linear", ["balance"]),
])
def test_model_feature_rules(service, key, features) -> None:
    with pytest.raises(ValidationError):
        service.train_regressor({"model": key, "target": "age", "features": features})


@pytest.mark.parametrize("target", ["deposit", "duration", "job"])
def test_invalid_targets_are_rejected(service, target) -> None:
    with pytest.raises(ValidationError):
        service.train_regressor({"model": "multiple_linear", "target": target, "features": ["age", "job"]})


def test_target_cannot_be_an_input(service) -> None:
    with pytest.raises(ValidationError):
        service.train_regressor({"model": "multiple_linear", "target": "age", "features": ["age", "balance"]})


def test_compare_runs_every_model_on_one_split(service) -> None:
    result = service.compare_regressors({"target": "balance", "features": ["age", "job", "housing"]})
    assert [r["model"] for r in result["rows"]] == list(reg.SPECS)
    assert result["rows"][0]["features_used"] == ["age"]  # the only numeric input
    assert not result["skipped"]


def test_regression_prediction(service) -> None:
    service.train_regressor({"model": "simple_linear", "target": "age", "features": ["balance"]})
    trained = service._models[("regression", "simple_linear")]
    result = service.predict({"task": "regression", "model": "simple_linear", "values": {"balance": 5000}})
    expected = trained.pipeline.predict(pd.DataFrame({"balance": [5000]}))[0]
    assert result["predicted"] == pytest.approx(expected) and result["unit"] == "years"
